package apcs_2012_FreeResponseQuestions;

public class Question4 {

	public static void main(String[] args) {
		int[][] pixelValues = { 
				{ 255, 184, 178, 84, 129 }, 
				{ 84, 255, 255, 130, 84 }, 
				{ 78, 255, 0, 0, 78 },
				{ 84, 130, 255, 130, 84 } };
		
		GrayImage img = new GrayImage(pixelValues);
		System.out.println(img);
		System.out.println("img.countWhitePixels() returns " + img.countWhitePixels());
		System.out.println();
		System.out.println("New version of array");
		int[][] pixelValues2 = { 
		{ 221, 184, 178, 84, 135 }, 
		{ 84, 255, 255, 130, 84 }, 
		{ 78, 255, 0, 0, 78 },
		{ 84, 130, 255, 130, 84 } };

		img = new GrayImage(pixelValues2);

		System.out.println(img);
		System.out.println("Call img.processImage()");
		System.out.println();
		img.processImage();
		System.out.println(img);
	}

}
