package apcs_2012_FreeResponseQuestions;

public class Arabian implements Horse {
	
	private String name;
	private int weight;

	public Arabian(String name, int weight) {
		super();
		this.name = name;
		this.weight = weight;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	@Override
	public String toString() {
//		return "(\"" + name + "\", " + weight + ")";
		return "\"" + name + "\"";
	}

	

}
