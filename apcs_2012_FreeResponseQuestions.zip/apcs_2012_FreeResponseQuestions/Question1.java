package apcs_2012_FreeResponseQuestions;

public class Question1 {

	public static void main(String[] args) {
		ClimbingClub hikerClubA = new ClimbingClub();
		hikerClubA.addClimbA("Monadnock", 274);
		hikerClubA.addClimbA("Whiteface", 301);
		hikerClubA.addClimbA("Algonquin", 225);
		hikerClubA.addClimbA("Monadnock", 344);
		System.out.println(hikerClubA.getClimbList());

		ClimbingClub hikerClubB = new ClimbingClub();
		hikerClubB.addClimbB("Monadnock", 274);
		hikerClubB.addClimbB("Whiteface", 301);
		hikerClubB.addClimbB("Algonquin", 225);
		hikerClubB.addClimbB("Monadnock", 344);
		System.out.println(hikerClubB.getClimbList());
		
		System.out.println("***********************************");
//		System.out.println((hikerClubA.distinctPeakNames() == 3) + ":\t" + hikerClubA.distinctPeakNames());
//		System.out.println((hikerClubB.distinctPeakNames() == 3) + ":\t" + hikerClubB.distinctPeakNames());
	}

}
