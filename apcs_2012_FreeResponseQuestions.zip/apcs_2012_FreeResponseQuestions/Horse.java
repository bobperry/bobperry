package apcs_2012_FreeResponseQuestions;

public interface Horse {
	/** @return the horse's name */
	String getName();

	/** @return the horse's weight */
	int getWeight();
	
// There may be methods that are not shown.
}