package apcs_2012_FreeResponseQuestions;

public class Question3 {

	public static void main(String[] args) {
		HorseBarn sweetHome = new HorseBarn(7);
		sweetHome.putHorse(0, new Arabian("Trigger", 1340));
		sweetHome.putHorse(2, new Arabian("Silver", 1210));
		sweetHome.putHorse(3, new Arabian("Lady", 1575));
		sweetHome.putHorse(5, new Arabian("Patches", 1350));
		sweetHome.putHorse(6, new Arabian("Duke", 1410));
		System.out.println("sweetHome: " + sweetHome);
		
		System.out.println("sweetHome.findHorseSpace(\"Trigger\") \treturns " + sweetHome.findHorseSpace("Trigger"));
		System.out.println("sweetHome.findHorseSpace(\"Silver\") \treturns " + sweetHome.findHorseSpace("Silver"));
		System.out.println("sweetHome.findHorseSpace(\"Coco\") \treturns " + sweetHome.findHorseSpace("Coco"));
		
		System.out.println();
		System.out.println("Remove \"Lady\"");
		sweetHome.putHorse(3, null);
		System.out.println("sweetHome: " + sweetHome);
		System.out.println("Call sweetHome.consolidate(); ");
		sweetHome.consolidate();
		System.out.println("sweetHome: " + sweetHome);

	}

}
