package apcs_2008_FreeResponseQuestions;

public class NotChecker implements Checker
{
    
    private Checker criterion;
    
    public NotChecker(Checker a) {
        criterion = a;
    }

    // The question didn't ask to write this, but I need it to test out
    // the code for the solution.   
    public boolean accept(String text) {
        return !criterion.accept(text);
    }
}
