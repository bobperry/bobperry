package apcs_2008_FreeResponseQuestions;

import apcs_2008_FreeResponseSolutions.AndChecker;
import apcs_2008_FreeResponseSolutions.Checker;
import apcs_2008_FreeResponseSolutions.NotChecker;
import apcs_2008_FreeResponseSolutions.SubstringChecker;

public class Question4
{
    public static void main(String[] args)
    {
    /* UNCOMMENT WHEN READY TO TEST... 
        Checker broccoliChecker = new SubstringChecker("broccoli");
        System.out.println("The following code should print: true, true, false, false");
        System.out.println(broccoliChecker.accept("broccoli"));
        System.out.println(broccoliChecker.accept("I like broccoli"));
        System.out.println(broccoliChecker.accept("carrots are great"));
        System.out.println(broccoliChecker.accept("Broccoli Bonanza"));
        
        Checker bChecker = new SubstringChecker("beets");
        Checker cChecker = new SubstringChecker("carrots");
        Checker bothChecker = new AndChecker(bChecker, cChecker);
        Checker aChecker = new SubstringChecker("artichokes");
        Checker veggies = new AndChecker(bothChecker, aChecker);
        
        System.out.println("\nThe following code should print: true, false, true");
        System.out.println(bothChecker.accept("I love beets and carrots"));
        System.out.println(bothChecker.accept("beets are great"));
        System.out.println(veggies.accept("artichokes, beets, and carrots")); 
        
        
//      PART C
//		Using any of the classes SubstringChecker, AndChecker, and NotChecker, 
//		construct a Checker that accepts a string if and only if 
//		it contains neither the substring "artichokes" nor the substring "kale". 
//		Assign the constructed Checker to yummyChecker. Consider the following
//		incomplete code segment.  
         
        //Checker aChecker = new SubstringChecker("artichokes");  // already done above
        Checker kChecker = new SubstringChecker("kale");
        Checker yummyChecker;
        // For part C, write your code below to construct and assign to yummyChecker 
        yummyChecker = null; // replace null with your answer 
        
        if(yummyChecker == null) {
        	System.out.println("Part C not done yet.");
        } else {
            System.out.println("\nThe following code should print: true, false, false");
            System.out.println(yummyChecker.accept("chocolate truffles"));
            System.out.println(yummyChecker.accept("kale is great"));
            System.out.println(yummyChecker.accept("Yuck: artichokes & kale"));        	
        }
        
    UNCOMMENT WHEN READY TO TEST... */
    }
}
