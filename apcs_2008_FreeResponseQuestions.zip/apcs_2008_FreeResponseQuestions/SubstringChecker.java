package apcs_2008_FreeResponseQuestions;

public class SubstringChecker 
{

	/*
	Write the SubstringChecker class that implements the Checker interface. The constructor should
	take a single String parameter that represents the particular substring to be matched.
	*/
}
