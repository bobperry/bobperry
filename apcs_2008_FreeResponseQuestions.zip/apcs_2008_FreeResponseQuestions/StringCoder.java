package apcs_2008_FreeResponseQuestions;

import java.util.ArrayList;

public class StringCoder
{
    public String masterString;

    public StringCoder(String master)
    {
        masterString = master;
    }

    // Solution to part (a)
    public String decodeString(ArrayList<StringPart> parts)
    {
    	/* To be implemented in part (a). */
        return null;
    }

    // Not part of the solution, but necessary to check the solution. For the
    // test, you simply assume this works.
    private StringPart findPart(String str)
    {
    	/* Implementation not shown in PDF, provided by Tutor Bob. */

        int max = 0;
        int start = 0, len = 0;

        // i represents the start of the match in the masterString
        for (int i = 0; i < masterString.length(); i++)
        {

            // j represents the index into the string str.
            int j = 0;
            int savei = i;
            while (savei < masterString.length() && j < str.length() &&
                masterString.charAt(savei) == str.charAt(j))
            {

                savei++;
                j++;
            }

            // This will trigger at least once, since we're guaranteed
            // by the pre-condition that there will be at least one match.
            if (j > max)
            {

                // Save the start and length of this match.
                start = savei - j;
                len = j;

                // Now we have a new match of maximum length.
                max = j;
            }

        }

        // This is the longest match we found.
        return new StringPart(start, len);
    }

    // Solution to part (b).
    public ArrayList<StringPart> encodeString(String word)
    {
    	/* To be implemented in part (b). */
        return null;

    }

    public static void main(String[] args)
    {

        StringCoder s =
            new StringCoder("sixtyzipperswerequicklypickedfromthewovenjutebag");

        ArrayList<StringPart> theseparts = s.encodeString("overeager");

        // Print out encoding
        for (int i = 0; i < theseparts.size(); i++)
            System.out.println(theseparts.get(i));

        String answer = s.decodeString(theseparts);
        System.out.println("Decoded strng is " + answer);

    }
}
