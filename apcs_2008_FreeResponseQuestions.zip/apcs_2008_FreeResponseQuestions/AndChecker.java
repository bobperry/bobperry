package apcs_2008_FreeResponseQuestions;

public class AndChecker 
{
    /*
     *  Write the AndChecker class that implements the Checker interface.
     *  The constructor should take two Checker parameters.
     *  The accept method returns true if and only if 
     *  the string is accepted by both of the Checker objects
     */
	
}
