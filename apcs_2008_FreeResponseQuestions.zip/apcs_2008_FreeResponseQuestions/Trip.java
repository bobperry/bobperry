package apcs_2008_FreeResponseQuestions;

import java.util.ArrayList;

public class Trip
{
    private ArrayList<Flight> flights;

    public Trip() {
        flights = new ArrayList<Flight>();
    }
    
    public void addNextLeg(Flight f) {
        flights.add(f);
    }
    
    public int getDuration() {
    	/* To be implemented in part (a). */
        return 0;               
    }
    
    public int getShortestLayover() {
    	/* To be implemented in part (b). */
        return 0;
    }

    public String toString() {
        String ans = "";
        for (int i=0; i<flights.size(); i++)
            ans = ans + flights.get(i) + "\n";
        return ans;
    }
}
