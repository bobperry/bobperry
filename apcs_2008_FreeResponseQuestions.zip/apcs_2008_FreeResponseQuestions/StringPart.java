package apcs_2008_FreeResponseQuestions;

public class StringPart
{
    public int start;
    public int length;
    
    public StringPart(int start, int length) {
        this.start = start;
        this.length = length;
    }
    
    public int getStart() {
        return start;
    }
    
    public int getLength() {
        return length;
    }
}
