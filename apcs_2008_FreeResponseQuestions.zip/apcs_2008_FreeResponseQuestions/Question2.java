package apcs_2008_FreeResponseQuestions;

import java.util.ArrayList;
import java.util.List;

public class Question2
{
    public static void main(String[] args)
    {
        // [ (37, 3), (14, 2), (46, 2), (9, 2) ]
        String code = "sixtyzipperswerequicklypickedfromthewovenjutebag";
        StringCoder coder = new StringCoder(code);
        ArrayList<StringPart> parts = new ArrayList<StringPart>();
        parts.add(new StringPart(37, 3));
        parts.add(new StringPart(14, 2));
        parts.add(new StringPart(46, 2));
        parts.add(new StringPart(9, 2));
        System.out.println("Decoding the 'parts' ArrayList should return the string: overeager.");
        System.out.println("Your code returned: " + coder.decodeString(parts));
        System.out.println();
        
        ArrayList<StringPart> parts2 = new ArrayList<StringPart>();
        parts2.add(new StringPart(11, 4));
        parts2.add(new StringPart(38, 2));
        System.out.println("Decoding the 'parts2' ArrayList should return the string: swerve."); 
        System.out.println("Your code returned: " + coder.decodeString(parts2));
        System.out.println();

        ArrayList<StringPart> encode = coder.encodeString("overeager");
        String ans = "";
        for(StringPart a : encode) {
            ans += code.substring(a.start, a.start + a.length);
        }
        System.out.println("Encoding the string 'overeager' should return an arraylist that decrypts to: overeager.");
        System.out.println("Your code returns an arraylist that decrypts to: " + ans);
//        System.out.println(coder.decodeString(coder.encodeString("overeager")));
        System.out.println();
        
        ArrayList<StringPart> encode2 = coder.encodeString("swerve");
        String ans2 = "";
        for(StringPart a : encode2) {
            ans2 += code.substring(a.start, a.start + a.length);
        }
        System.out.println("Encoding the string 'swerve' should return an arraylist that decrypts to: swerve.");
        System.out.println("Your code returns an arraylist that decrypts to: " + ans2);
        
    }
}
