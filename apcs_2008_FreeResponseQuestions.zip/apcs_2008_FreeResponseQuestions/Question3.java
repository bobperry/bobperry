package apcs_2008_FreeResponseQuestions;

public class Question3
{
    public static void main(String[] args)
    {
        System.out.println(
            "Skip this question because the GridWorld case study is no longer part of the AP Computer Science A exam.");
    }
}
