package apcs_2008_FreeResponseQuestions;

public class Flight
{
    private Time depart;
    private Time arrive;
    
    public Flight(Time start, Time end) {
        depart = start;
        arrive = end;
    }   
        
    public Time getDepartureTime() {
        return depart;
    }

    public Time getArrivalTime() {
        return arrive;
    }
    
    public String toString() {
        return depart+" to "+arrive;
    }

}
