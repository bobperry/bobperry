package apcs_2008_FreeResponseQuestions;

public class Time
{
    int hour;
    int minute;
    
    public Time() {
        hour = 0;
        minute = 0;
    }
    
    public Time(int hour, int minute) {
        this.hour = hour;
        this.minute = minute;
    }
    public int minutesUntil(Time other) {
        return 60*(other.hour - this.hour) + other.minute - this.minute;
    }

}
