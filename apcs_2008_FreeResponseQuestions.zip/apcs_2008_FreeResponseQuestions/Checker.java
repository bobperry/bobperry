package apcs_2008_FreeResponseQuestions;

public interface Checker
{
        boolean accept(String text);
}
