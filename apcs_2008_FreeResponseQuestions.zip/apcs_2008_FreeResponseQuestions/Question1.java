package apcs_2008_FreeResponseQuestions;

public class Question1
{
    public static void main(String[] args) {
        Trip journey = new Trip();
        journey.addNextLeg(new Flight(new Time(11, 30), new Time(12, 15)));
        journey.addNextLeg(new Flight(new Time(13, 15), new Time(15, 45)));
        journey.addNextLeg(new Flight(new Time(16, 0), new Time(18, 45)));
        journey.addNextLeg(new Flight(new Time(20, 15), new Time(23, 0)));
        
        System.out.println("The time between the first departure and the last arrival of the first journey is 690 minutes.");
        System.out.println("Your code says the time difference is: " + journey.getDuration() + " minutes.");
        
        Trip journey2 = new Trip();
        journey2.addNextLeg(new Flight(new Time(2, 0), new Time(14, 0)));
        journey2.addNextLeg(new Flight(new Time(15, 30), new Time(21, 45)));
        journey2.addNextLeg(new Flight(new Time(22, 30), new Time(23, 45)));
        
        System.out.println("\nThe time between the first departure and the last arrival of the second journey is 1305 minutes.");
        System.out.println("Your code says the time difference is: " + journey2.getDuration() + " minutes.");
        
        
        System.out.println("\nThe shortest layover on the first journey lasts 15 minutes.");
        System.out.println("Your code says the shortest layover lasts: " + journey.getShortestLayover() + " minutes.");
        
        System.out.println("\nThe shortest layover on the second journey lasts 45 minutes.");
        System.out.println("Your code says the shortest layover lasts: " + journey2.getShortestLayover() + " minutes.");
        
    }
}
