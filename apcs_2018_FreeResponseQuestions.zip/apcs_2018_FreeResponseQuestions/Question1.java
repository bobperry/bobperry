package apcs_2018_FreeResponseQuestions;  // https://apcentral.collegeboard.org/pdf/ap18-frq-computer-science-a.pdf

public class Question1 {
	
	public static void main(String[] args) {
		FrogSimulation sim = new FrogSimulation(24,5);
		System.out.println(sim.runSimulations(100));
	}

}
