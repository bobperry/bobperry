package apcs_2018_FreeResponseQuestions;

public interface StringChecker {
	boolean isValid(String str);
}
