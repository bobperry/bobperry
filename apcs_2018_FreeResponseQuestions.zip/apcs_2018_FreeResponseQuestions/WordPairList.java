package apcs_2018_FreeResponseQuestions;

import java.util.ArrayList;

public class WordPairList {

	private ArrayList<WordPair> allPairs;
	
	public WordPairList(String[] words) {
	}
	
	public int numMatches() {
		return 0;
	}
	
	public String toString() {
		return String.valueOf(allPairs);
	}
}
