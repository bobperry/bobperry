package apcs_2018_FreeResponseQuestions;

public class FrogSimulation {
	
	private int goalDistance;
	private int maxHops;
	
	

	public FrogSimulation(int dist, int numHops) {
		goalDistance = dist;
		maxHops = numHops;
	}


	private int hopDistance() {
		return generateRandom(-8,31);
	}

	private int generateRandom(int low, int high) {
		// randomly generate an int between low & high, inclusive
		int range = high - low + 1;
		return (int) (Math.random() * range) + low;
	}

	public boolean simulate() 
	{
		return false;
	}

	public double runSimulations(int num) 
	{
		return 0;
	}
	

}
