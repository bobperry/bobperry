package apcs_2019_FreeResponseQuestions;

import java.util.ArrayList;
import java.util.Arrays;

public class Question3 {

	public static void main(String[] args) {
		System.out.println("=============== Example A1 ===============");
		Delimiters exampleA1 = new Delimiters("(", ")");
		String[] tokensA1 = { "(", "x + y", ")", " * 5" };
		ArrayList<String> listA1 = exampleA1.getDelimitersList(tokensA1);
		System.out.println("Delimiters: " + exampleA1);
		System.out.println("Tokens: " + Arrays.toString(tokensA1));
		System.out.println("getDelimitersList: " + listA1);
		System.out.println("isBalanced? " + exampleA1.isBalanced(listA1));

		System.out.println("=============== Example A2 ===============");
		Delimiters exampleA2 = new Delimiters("<q>", "</q>");
		String[] tokensA2 = { "<q>", "yy", "</q>", "zz", "</q>" };
		ArrayList<String> listA2 = exampleA2.getDelimitersList(tokensA2);
		System.out.println("Delimiters: " + exampleA2);
		System.out.println("Tokens: " + Arrays.toString(tokensA2));
		System.out.println("getDelimitersList: " + listA2);
		System.out.println("isBalanced? " + exampleA2.isBalanced(listA2));

		System.out.println("=============== Example B1 ===============");
		Delimiters exampleB1 = new Delimiters("<sup>", "</sup>");
		String[] tokensB1 = { "<sup>", "<sup>", "</sup>", "<sup>", "</sup>", "</sup>"};
		ArrayList<String> listB1 = exampleB1.getDelimitersList(tokensB1);
		System.out.println("Delimiters: " + exampleB1);
		System.out.println("Tokens: " + Arrays.toString(tokensB1));
		System.out.println("getDelimitersList: " + listB1);
		System.out.println("isBalanced? " + exampleB1.isBalanced(listB1));

		System.out.println("=============== Example B2 ===============");
		Delimiters exampleB2 = new Delimiters("<sup>", "</sup>");
		String[] tokensB2 = { "<sup>", "</sup>", "</sup>", "<sup>"};
		ArrayList<String> listB2 = exampleB2.getDelimitersList(tokensB2);
		System.out.println("Delimiters: " + exampleB2);
		System.out.println("Tokens: " + Arrays.toString(tokensB2));
		System.out.println("getDelimitersList: " + listB2);
		System.out.println("isBalanced? " + exampleB2.isBalanced(listB2));

		System.out.println("=============== Example B3 ===============");
		Delimiters exampleB3 = new Delimiters("<sup>", "</sup>");
		String[] tokensB3 = { "</sup>"};
		ArrayList<String> listB3 = exampleB3.getDelimitersList(tokensB3);
		System.out.println("Delimiters: " + exampleB3);
		System.out.println("Tokens: " + Arrays.toString(tokensB3));
		System.out.println("getDelimitersList: " + listB3);
		System.out.println("isBalanced? " + exampleB3.isBalanced(listB3));


		System.out.println("=============== Example B4 ===============");
		Delimiters exampleB4 = new Delimiters("<sup>", "</sup>");
		String[] tokensB4 = { "<sup>", "<sup>", "</sup>"};
		ArrayList<String> listB4 = exampleB4.getDelimitersList(tokensB4);
		System.out.println("Delimiters: " + exampleB4);
		System.out.println("Tokens: " + Arrays.toString(tokensB4));
		System.out.println("getDelimitersList: " + listB4);
		System.out.println("isBalanced? " + exampleB4.isBalanced(listB4));

		System.out.println("=========================================");

      }


}
