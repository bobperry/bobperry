package apcs_2019_FreeResponseQuestions;

/**
 * 4. The LightBoard class models a two-dimensional display of lights, where
 * each light is either on or off, as represented by a Boolean value. You will
 * implement a constructor to initialize the display and a method to evaluate a
 * light.
 */

public class LightBoard {
	/**
	 * The lights on the board, where true represents on and false represents off.
	 */
	private boolean[][] lights;

	/**
	 * Constructs a LightBoard object having numRows rows and numCols columns.
	 * Precondition: numRows > 0, numCols > 0 Postcondition: each light has a 40%
	 * probability of being set to on. The notation lights[r][c] represents the
	 * array element at row r and column c.
	 */
	public LightBoard(int numRows, int numCols) {
		/* to be implemented in part (a) */
	}

	/**
	 * Evaluates a light in row index row and column index col and returns a status
	 * as described in part (b).
	 * 
	 * (b) Write the method evaluateLight, which computes and returns the status of
	 * a light at a given row and column based on the following rules. 1. If the
	 * light is on, return false if the number of lights in its column that are on
	 * is even, including the current light. 2. If the light is off, return true if
	 * the number of lights in its column that are on is divisible by three. 3.
	 * Otherwise, return the light's current status. For example, suppose that
	 * LightBoard sim = new LightBoard(7, 5) creates a light board with the initial
	 * state shown below, where true represents a light that is on and false
	 * represents a light that is off. Lights that are off are shaded. lights 0 1 2
	 * 3 4 0 1 2 3 4 5 6 true true false true true true false false true false true
	 * false false true true true false false false true true false false false true
	 * true true false true true false false false false false Sample calls to
	 * evaluateLight are shown below. Call to evaluateLight Value Returned
	 * Explanation sim.evaluateLight(0, 3); false The light is on, and the number of
	 * lights that are on in its column is even. sim.evaluateLight(6, 0); true The
	 * light is off, and the number of lights that are on in its column is divisible
	 * by 3. sim.evaluateLight(4, 1); false Returns the light's current status.
	 * sim.evaluateLight(5, 4); true Returns the light's current status.
	 * 
	 * Precondition: row and col are valid indexes in lights.
	 */
	public boolean evaluateLight(int row, int col) {
		/* to be implemented in part (b) */
			return false;
	}

	// There may be additional instance variables, constructors, and methods not
	// shown.
	public String toString() {
		if(lights == null) return "null";
		int rows = lights.length;
		int cols = lights[0].length;
		String s = "R \\ C ";
		for (int col = 0; col < cols; col++) {
			s += "   " + col + "  ";
		}
		s += "\n";
		int[] numOnInColumn = new int[cols];
		int totalOn = 0;
		int totalLights = rows * cols;

		for (int row = 0; row < rows; row++) {
			s += "  " + row + "   ";
			for (int col = 0; col < cols; col++) {
				boolean on = lights[row][col];
				if (on) {
					numOnInColumn[col]++;
					totalOn++;
				}
				s += String.format("%6s", String.valueOf(on));
			}
			s += "\n";
		}
		s += "#OnInCol ";
		for (int col = 0; col < cols; col++) {
			s += numOnInColumn[col] + "     ";
		}
		s += "Total On = " + totalOn + "\n";
		s += "Percent On = 100 * " + totalOn + " / " + totalLights + " = " + (100 * totalOn / totalLights) + "\n"; 

		return s;
	}

	public String evaluateAllLights() {
		if(lights == null) return "null";
		int rows = lights.length;
		int cols = lights[0].length;
		String s = "R \\ C ";
		for (int col = 0; col < cols; col++) {
			s += "   " + col + "  ";
		}
		s += "\n";
		for (int row = 0; row < rows; row++) {
			s += "  " + row + "   ";
			for (int col = 0; col < cols; col++) {
				boolean on = evaluateLight(row, col);
				s += String.format("%6s", String.valueOf(on));
			}
			s += "\n";
		}
		return s;
	}
}
