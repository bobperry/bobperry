package apcs_2019_FreeResponseQuestions;

public class Question2 {

	public static void main(String[] args) {
		System.out.println("UNCOMMENT WHEN READY TO TEST...");
	/* UNCOMMENT WHEN READY TO TEST... 
		StepTracker tr = new StepTracker(10000);
		System.out.println("StepTracker tr = new StepTracker(10000)");
		int activeDays = tr.activeDays(); // 0 No data have been recorded yet.
		System.out.println("activeDays = " + activeDays);
		double averageSteps = tr.averageSteps(); // 0.0 When no step data have been recorded
		System.out.println("averageSteps = " + averageSteps);
		
		tr.addDailySteps(9000); // This is too few steps for the day to be considered active.
		System.out.println("tr.addDailySteps(9000);");
		tr.addDailySteps(5000); // This is too few steps for the day to be considered active.
		System.out.println("tr.addDailySteps(5000);");
		activeDays = tr.activeDays(); // 0 No day had at least 10,000 steps.
		System.out.println("activeDays = " + activeDays);
		averageSteps = tr.averageSteps(); // 7000.0 The average number of steps per day is (14000 / 2).
		System.out.println("averageSteps = " + averageSteps);
		
		tr.addDailySteps(13000); // This represents an active day.
		System.out.println("tr.addDailySteps(13000);");
		activeDays = tr.activeDays(); // 1 Of the three days for which step data were entered, one day had at least 10,000 steps.
		System.out.println("activeDays = " + activeDays);
		averageSteps = tr.averageSteps(); // 9000.0 The average number of steps per day is (27000 / 3).
		System.out.println("averageSteps = " + averageSteps);
		
		tr.addDailySteps(23000); // This represents an active day.
		System.out.println("tr.addDailySteps(23000);");
		tr.addDailySteps(1111); // This is too few steps for the day to be considered active.
		System.out.println("tr.addDailySteps(1111);");
		activeDays = tr.activeDays(); // 2 Of the five days for which step data were entered, two days had at least 10,000 steps.
		System.out.println("activeDays = " + activeDays);
		averageSteps = tr.averageSteps(); // 10222.2 The average number of steps per day is (51111 / 5).
		System.out.println("averageSteps = " + averageSteps);
	UNCOMMENT WHEN READY TO TEST... */
	}

}
