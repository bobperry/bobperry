package apcs_2019_FreeResponseQuestions;

import java.util.ArrayList;

/*
Write the complete StepTracker class, including the constructor and any required instance variables and
methods. Your implementation must meet all specifications and conform to the example.
 */
public class StepTracker {
	
}
