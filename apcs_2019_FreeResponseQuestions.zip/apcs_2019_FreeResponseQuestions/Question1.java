package apcs_2019_FreeResponseQuestions;

public class Question1 {

	public static void main(String[] args) {
		System.out.println("Number of Leap Years in 1900-2020: " + APCalendar.numberOfLeapYears(1900, 2020));
		System.out.println("Number of Leap Years in 2000-2020: " + APCalendar.numberOfLeapYears(2000, 2020));
		System.out.println("======================");

		String[] dayNames = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

		int day = APCalendar.dayOfWeek(1, 1, 2019);
		System.out.println("APCalendar.dayOfWeek(1, 1, 2019) returns " + day + ", which is a " + dayNames[day]);

		day = APCalendar.dayOfWeek(1, 5, 2019);
		System.out.println("APCalendar.dayOfWeek(1, 5, 2019) returns " + day + ", which is a " + dayNames[day]);

		day = APCalendar.dayOfWeek(1, 10, 2019);
		System.out.println("APCalendar.dayOfWeek(1, 10, 2019) returns " + day + ", which is a " + dayNames[day]);
		System.out.println("======================");

		day = APCalendar.dayOfWeek(1, 1, 2021);
		System.out.println("APCalendar.dayOfWeek(1, 1, 2021) returns " + day + ", which is a " + dayNames[day]);

		day = APCalendar.dayOfWeek(1, 2, 2021);
		System.out.println("APCalendar.dayOfWeek(1, 2, 2021) returns " + day + ", which is a " + dayNames[day]);

		day = APCalendar.dayOfWeek(1, 3, 2021);
		System.out.println("APCalendar.dayOfWeek(1, 3, 2021) returns " + day + ", which is a " + dayNames[day]);

		System.out.println("======================");
		System.out.println("The 2021 AP Computer Science A Exam was on Thursday, May 6, 2021.");
		day = APCalendar.dayOfWeek(5, 6, 2021);
		System.out.println("APCalendar.dayOfWeek(5, 6, 2021) returns " + day + ", which is a " + dayNames[day]);
		
        System.out.println("======================");
        System.out.println("The 2022 AP Computer Science A Exam is on Wednesday, May 4, 2022.");
        day = APCalendar.dayOfWeek(5, 4, 2022);
        System.out.println("APCalendar.dayOfWeek(5, 4, 2022) returns " + day + ", which is a " + dayNames[day]);

	}

}
