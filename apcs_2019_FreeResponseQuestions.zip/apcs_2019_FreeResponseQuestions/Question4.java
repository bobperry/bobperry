package apcs_2019_FreeResponseQuestions;

public class Question4 {

	public static void main(String[] args) {
		LightBoard sim = new LightBoard(7, 5);
		System.out.println("LightBoard:");
		System.out.println(sim);
		System.out.println("Evaluate all lights on LightBoard:");
		System.out.println("Computes the status at a given row and column based on the following rules:");
		System.out.println("  1. If the light is on, return false if # of lights in column that are on is even");
		System.out.println("  2. If the light is off, return true if # of lights in column that are on is divisible by three.");
		System.out.println("  3. Otherwise, return the light's current status.\n");
		System.out.println(sim.evaluateAllLights());
	}

}
