package apcs_2005_FreeResponseQuestions;

public class Question1
{
    public static void main(String[] args)
    {
        Hotel hotel = new Hotel(3);
        System.out.println("New 3-room hotel:");
        System.out.println(hotel);
        System.out.println("Adam requests a room");
        Reservation resA = hotel.requestRoom("Adam");
        System.out.println("Request returns: " + resA);
        System.out.println(hotel);
        System.out.println("Ben requests a room");
        Reservation resB = hotel.requestRoom("Ben");
        System.out.println("Request returns: " + resB);
        System.out.println(hotel);
        System.out.println("Charles requests a room");
        Reservation resC = hotel.requestRoom("Charles");
        System.out.println("Request returns: " + resC);
        System.out.println(hotel);
        System.out.println("Dennis requests a room");
        Reservation resD = hotel.requestRoom("Dennis");
        System.out.println("Request returns: " + resD);
        System.out.println(hotel);
        System.out.println("Edward requests a room");
        Reservation resE = hotel.requestRoom("Edward");
        System.out.println("Request returns: " + resE);
        System.out.println(hotel);
        System.out.println("Ben cancels his reservation");
        Reservation resF = hotel.cancelAndReassign(resB);
        System.out.println("Request returns: " + resF);
        System.out.println(hotel);
        System.out.println("Charles cancels his reservation");
        Reservation resG = hotel.cancelAndReassign(resC);
        System.out.println("Request returns: " + resG);
        System.out.println(hotel);
        System.out.println("Adam cancels his reservation");
        Reservation resH = hotel.cancelAndReassign(resA);
        System.out.println("Request returns: " + resH);
        System.out.println(hotel);

    }
}
