package apcs_2005_FreeResponseQuestions;

public abstract class Ticket
{
    private int serialNumber;
    
	/* not shown in PDF */
    private static int nextSerialNumber = 100;
    
    public Ticket() {
        serialNumber= getNextSerialNumber();
    }
    
    public abstract double getPrice();
    
    public String toString() {
    	String s = this.getClass().getSimpleName() + " Ticket\n";
    	s += " Number: " + serialNumber + "\n Price: " + getPrice() + "\n";
        return s;
    }
    
    private static int getNextSerialNumber() {
    	/* implementation not shown in PDF */
    	nextSerialNumber++;
    	return nextSerialNumber;
    }
}
