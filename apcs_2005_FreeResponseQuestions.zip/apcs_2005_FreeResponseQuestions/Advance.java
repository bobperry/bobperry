package apcs_2005_FreeResponseQuestions;

public class Advance // what is needed here?
{
	/*
	 * Write the complete class declaration for the class Advance. Include all
	 * necessary instance variables and implementations of its constructor and
	 * method(s). The constructor should take a parameter that indicates the number
	 * of days in advance that this ticket is being purchased. 
	 * Tickets purchased ten or more days in advance cost $30; 
	 * Tickets purchased nine or fewer days in advance cost $40.
	 */
}
