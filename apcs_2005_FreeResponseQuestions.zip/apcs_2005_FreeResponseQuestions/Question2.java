package apcs_2005_FreeResponseQuestions;

public class Question2
{
    public static void main(String[] args)
    {
    	System.out.println("Ticket t1 = new Walkup();  // Should cost 50");
    	Ticket t1 = new Walkup();
    	System.out.println(t1);
    	
    	System.out.println("Uncomment when ready to test...");
    	/* Uncomment when ready to test...
    	System.out.println("Ticket t2 = new Advance(5);  // Should cost 40");
    	Ticket t2 = new Advance(5);
    	System.out.println(t2);
    	
    	System.out.println("Ticket t3 = new Advance(10);  // Should cost 30");
    	Ticket t3 = new Advance(10);
    	System.out.println(t3);
    	
    	System.out.println("Ticket t4 = new StudentAdvance(5);  // Should cost 20");
    	Ticket t4 = new StudentAdvance(5);
    	System.out.println(t4);
    	
    	System.out.println("Ticket t5 = new StudentAdvance(10);  // Should cost 15");
    	Ticket t5 = new StudentAdvance(10);
    	System.out.println(t5);
    	*/

    }
}
