package apcs_2005_FreeResponseQuestions;

public class Reservation
{
	// private data not shown in PDF 
    private String guestName;
    private int roomNumber = 0;
    
    public Reservation(String guestName, int roomNumber) {
    	/* implementation not shown in PDF */
        this.guestName = guestName;
        this.roomNumber = roomNumber;
    }
    
    public int getRoomNumber() {
    	/* implementation not shown in PDF */
        return roomNumber;
    }

    // other methods not shown in PDF
	public String getGuestName() {
		return guestName;
	}

	public String toString() {
		return "Reservation [guest=" + guestName + ", room=" + roomNumber + "]";
	}

	
}
