package apcs_2005_FreeResponseQuestions;

public class Walkup extends Ticket
{
    public double getPrice()
    {
        return 50;
    }
    
}
