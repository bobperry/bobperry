package apcs_2005_FreeResponseQuestions;

import java.util.Arrays;

public class Question4
{
    public static void main(String[] args)
    {
        int[] score1 = {50,50,20,80,53};
        StudentRecord one = new StudentRecord(score1);
        int[] score2 = {20,50,50,53,80};
        StudentRecord two = new StudentRecord(score2);
        int[] score3 = {20,50,50,80};
        StudentRecord three = new StudentRecord(score3);
        
        System.out.println("Student one's scores: " + Arrays.toString(score1));
        System.out.println("The final average for student one should be 50.6. \nYour code says their final average is: " + one.finalAverage());
        System.out.println();
        System.out.println("Student two's scores: " + Arrays.toString(score2));
        System.out.println("The final average for student two should be 61.0. \nYour code says their final average is: " + two.finalAverage());
        System.out.println();
        System.out.println("Student three's scores: " + Arrays.toString(score3));
        System.out.println("The final average for student three should be 65.0. \nYour code says their final average is: " + three.finalAverage());
    }
}
