package apcs_2005_FreeResponseQuestions;

public class StudentRecord
{
	private int[] scores;

	/* Constructor not shown in PDF */
    public StudentRecord(int[] scores)
    {
        this.scores = scores;
    }

    private double average(int first, int last)
    {
    	/* to be implemented in part (a) */
        return 0;
    }

    private boolean hasImproved()
    {
    	/* to be implemented in part (b) */
        return false;
    }

    public double finalAverage()
    {
    	/* to be implemented in part (c) */
    	return 0;
    }
}
