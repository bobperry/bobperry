package apcs_2022_FreeResponseQuestions;

/*
 I. This question involves simulation of the play and scoring of a single-player video game. 
 In the game, a player attempts to complete three levels. 
 A level in the game is represented by the Level class.
 */
public class Level {

	/** Returns true if the player reached the goal on this level and returns false otherwise */
	public boolean goalReached()
	{ 
		/* implementation not shown in PDF */
		return goalReached;
	}
	
	/** Returns the number of points (a positive integer) recorded for this level */
	public int getPoints()
	{ 
		/* implementation not shown in PDF*/
		return points;
	}
	
	// There may be instance variables, constructors, and methods that are not shown.
	
	private boolean goalReached;
	private int points;
	
	public Level() {
		this(false, 0);
	}

	public Level(boolean goalReached, int points) {
		super();
		this.goalReached = goalReached;
		this.points = points;
	}

	public void setGoalReached(boolean goalReached) {
		this.goalReached = goalReached;
	}

	public void setPoints(int points) {
		this.points = points;
	}

	@Override
	public String toString() {
		return "[goalReached=" + goalReached + ", points=" + points + "]\n";
	}
	
	

}
