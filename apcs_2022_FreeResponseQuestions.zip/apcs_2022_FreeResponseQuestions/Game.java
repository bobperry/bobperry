package apcs_2022_FreeResponseQuestions;

//Play of the game is represented by the Game class. You will write two methods of the Game class.

public class Game {

	private Level levelOne;
	private Level levelTwo;
	private Level levelThree;

	/** Postcondition: All instance variables have been initialized. */
	public Game() {
		/* Implementation not shown in PDF */
	}

	/** Returns true if this game is a bonus game and returns false otherwise */
	public boolean isBonus() {
		/* Implementation not shown in PDF */
		return bonus;
	}

	/**
	 * Simulates the play of this Game (consisting of three levels) and updates all
	 * relevant game data
	 */
	public void play() {
		/* Implementation not shown in PDF */
	}

	/**
	 * Returns the score earned in the most recently played game, as described in part (a)

		(a) Write the getScore method, which returns the score for the most recently played game. Each game
		consists of three levels. The score for the game is computed using the following helper methods.
		� The isBonus method of the Game class returns true if this is a bonus game
		and returns false otherwise.
		� The goalReached method of the Level class returns true if the goal has
		been reached on a particular level and returns false otherwise.
		� The getPoints method of the Level class returns the number of points recorded
		on a particular level. Whether or not recorded points are earned (included in the game
		score) depends on the rules of the game, which follow.
		
		The score for the game is computed according to the following rules.
		� Level one points are earned only if the level one goal is reached. Level two points are
		earned only if both the level one and level two goals are reached. Level three points are
		earned only if the goals of all three levels are reached.
		� The score for the game is the sum of the points earned for levels one, two, and three.
		� If the game is a bonus game, the score for the game is tripled.
		  
	 */
	public int getScore() {
		/* to be implemented in part (a) */
		return 0; // change this to correctly calculate and return score
	}

	/**
	 * Simulates the play of num games and returns the highest score earned, 
	 * as described in part (b) 
	 
		(b) Write the playManyTimes method, which simulates the play of num games and returns the
		highest game score earned. For example, if the four plays of the game that are. simulated as a result of the
		method call playManyTimes (4) earn scores of 75, 50, 90, and 20, then the method
		should return 90.
		
		Play of the game is simulated by calling the helper method play. Note that if play is called only
		one time followed by multiple consecutive calls to getScore, each call to getScore will return
		the score earned in the single simulated play of the game.
		
		Complete the playManyTimes method. Assume that getScore works as intended, regardless
		of what you wrote in part (a). You must call play and getScore appropriately in order to receive
		full credit.

	 * Precondition: num > 0
	 */
	public int playManyTimes(int num) {
		/* to be implemented in part (b) */
		return 0; // change this to correctly calculate and return highest score earned
	}

	//There may be instance variables, constructors, and methods that are not shown.		
	
	private boolean bonus;

	public Game(boolean goalReached1, int points1, boolean goalReached2, int points2, boolean goalReached3, int points3, boolean bonus) {
		super();
		levelOne = new Level(goalReached1, points1);
		levelTwo = new Level(goalReached2, points2);
		levelThree = new Level(goalReached3, points3);
		this.bonus = bonus;
	}

	public Level getLevelOne() {
		return levelOne;
	}

	public void setLevelOne(Level levelOne) {
		this.levelOne = levelOne;
	}

	public Level getLevelTwo() {
		return levelTwo;
	}

	public void setLevelTwo(Level levelTwo) {
		this.levelTwo = levelTwo;
	}

	public Level getLevelThree() {
		return levelThree;
	}

	public void setLevelThree(Level levelThree) {
		this.levelThree = levelThree;
	}

	public void setBonus(boolean bonus) {
		this.bonus = bonus;
	}

	@Override
	public String toString() {
		return "Game:\n\t levelOne:\t" + levelOne + "\t levelTwo:\t" + levelTwo + "\t levelThree:\t" + levelThree + "\t bonus:\t\t"
				+ bonus + "\n\t score:\t\t" + getScore() +  "\n";
	}	
	
}