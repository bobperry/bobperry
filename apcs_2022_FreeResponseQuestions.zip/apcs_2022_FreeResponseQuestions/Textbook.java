package apcs_2022_FreeResponseQuestions;

/*
You will write a class Textbook, which is a subclass of Book.
A Textbook has an edition number, which is a positive integer used to identify different versions of the book. 
The getBookinfo method, when called on a Textbook, returns a string that also includes the
edition information, as shown in the example.
Information about the book title and price must be maintained in the Book class. 
Information about the edition must be maintained in the Textbook class.
The Textbook class contains an additional method, canSubstituteFor, which returns true if
a Textbook is a valid substitute for another Textbook and returns false otherwise. 
The current Textbook is a valid substitute for the Textbook referenced by the parameter of the
canSubstituteFor method if the two Textbook objects have the same title and if the edition of the
current Textbook is greater than or equal to the edition of the parameter.
Write the complete Textbook class. 
Your implementation must meet all specifications and conform to the examples shown in the table.
*/

