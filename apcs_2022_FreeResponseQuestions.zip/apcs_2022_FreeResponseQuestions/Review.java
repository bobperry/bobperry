package apcs_2022_FreeResponseQuestions;

/*
3. Users of a website are asked to provide a review of the website at the end of each visit. Each review,
represented by an object of the Review class, consists of an integer indicating the user's rating of the
website and an optional String comment field. The comment field in a Review object ends with a
period ("."), exclamation point ("!"), or letter, or is a String of length 0 if the user did not enter
a comment.
*/
public class Review {
	private int rating;
	private String comment;

	/**
	 * Precondition: r > = 0 c is not null.
	 */
	public Review(int r, String c) {
		rating = r;
		comment = c;
	}

	public int getRating() {
		return rating;
	}

	public String getComment() {
		return comment;
	}
	
	// There may be instance variables, constructors, and methods that are not shown.
}
