package apcs_2022_FreeResponseQuestions;

import java.util.Arrays;

/*
4. This question involves a two-dimensional array of integers that represents a collection of randomly generated
data. A partial declaration of the Data class is shown. You will write two methods of the Data class.
*/
public class Data {

	public static final int MAX = 1000; /* value not shown in PDF */	
	private int[][] grid;

	/**
	 * Fills all elements of grid with randomly generated values, as described in
	 * part (a)
	 * 
	 * (a) Write the repopulate method. which assigns a newly generated random value
	 * to each element of grid. Each value is computed to meet all of the following
	 * criteria, and all valid values must have an equal chance of being generated.
	 * � The value is between 1 and MAX, inclusive. � The value is divisible by 10.
	 * � The value is not divisible by 100.
	 * 
	 * Precondition: grid is not null. grid has at least one element.
	 */
	public void repopulate() {
		/* to be implemented in part (a) */
	}


	/**
	 * Returns the number of columns in grid that are in increasing order, as
	 * described in part (b)
	 * 
	 * (b) Write the countincreasingCols method, which returns the number of columns
	 * in grid that are in increasing order. A column is considered to be in
	 * increasing order if the element in each row after the first row is greater
	 * than or equal to the element in the previous row. A column with only one row
	 * is considered to be in increasing order.
	 * 
	 * 
	 * Precondition: grid is not null. grid has at least one element.
	 */
	public int countincreasingCols() {
		/* to be implemented in part (b) */
		return 0;
	}

	//There may be instance variables, constructors, and methods that are not shown.
	
	public Data(int[][] grid) {
		super();
		this.grid = grid;
	}

	@Override
	public String toString() {
		String s = "Data:\n";
		for (int[] row : grid) {
			for (int i : row) {
				s += String.format("%4d", i);
			}
			s += "\n";
		}
		s += "countincreasingCols() returns " + countincreasingCols();
		return s;
	}
	
}