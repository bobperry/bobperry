package apcs_2022_FreeResponseQuestions;

public class GameB extends Game {
	int[] scores = {75, 50, 90, 20};
	int rounds = 0;
	
	/**
	 * Simulates the play of this Game (consisting of three levels) and updates all
	 * relevant game data
	 */
	public void play() {
		rounds++;
	}

	/**
	 * Returns the score earned in the most recently played game
	 */
	public int getScore() {
		int index = (rounds-1) % scores.length;
		int multiplier = 1 + rounds / scores.length;
		return scores[index] * multiplier;
	}

}
