package apcs_2022_FreeResponseQuestions;

import java.util.ArrayList;

/*
The ReviewAnalysis class contains methods used to analyze the reviews provided by users. You will
write two methods of the ReviewAnalysis class.
*/

public class ReviewAnalysis {
	
	/** All user reviews to be included in this analysis */
	private Review[] allReviews;

	/** Initializes allReviews to contain all the Review objects to be analyzed */
	public ReviewAnalysis() {
		/* implementation not shown */
	}

	/**  (a) Write the ReviewAnalysis method getAverageRating,  
	 * which returns the average rating (arithmetic mean) of all elements of allReviews.
	 *   
	 * Returns a double representing the average rating of all the Review objects to
	 * be analyzed, as described in part (a) 
	 * Precondition: allReviews contains at least one Review. No element of allReviews is null.
	 */
	public double getAverageRating() {
		/* to be implemented in part (a) */
		return 0;
	}

	/**
	 * Returns an ArrayList of String objects containing formatted versions of
	 * selected user comments, as described in part (b) 
	 * 
	 * (b) Write the ReviewAnalysis method collectComments. which co11ects and fonnats only
comments that contain an exclamation point. The method returns an ArrayList of String
objects containing copies of user comments from allReviews that contain an exclamation point,
formatted as fo11ows. An empty ArrayList is returned if no comment in allReviews contains
an exclamation point.
� The String inserted into the ArrayList to be returned begins with the index of
the Review in allReviews.
� The index is immediately followed by a hyphen (" - ").
� The hyphen is followed by a copy of the original comment.
� The String must end with either a period or an exclamation point. If the original
comment from allReviews does not end in either a period or an exclamation point,
a period is added.
The following example of allReviews is repeated from pan (a).
0 1 2 3 4
4 3 5 2 I: . "Good! Thx" "OK site" "Great! " "Poor! Bad."
The following ArrayList would be returned by a call to collectComments with the given
contents of allReviews. The reviews at index 1 and index 4 in allReviews are not
included in the ArrayList to return since neither review contains an exclamation point.
1"0-Good! Thx."l I "2- Great!" 1"3-Poor! Bad."l
Complete method collectComments.

	 * 
	 * Precondition: allReviews contains at least one Review. No element of allReviews is null.
	 * Postcondition: allReviews is unchanged.
	 */
	public ArrayList<String> collectComments() {
		/* to be implemented in part (b) */
		return null;
	}

	// There may be instance variables, constructors, and methods that are not shown.

	public ReviewAnalysis(Review[] allReviews) {
		super();
		this.allReviews = allReviews;
	}

}
