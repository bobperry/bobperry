package apcs_2022_FreeResponseQuestions;

import java.util.ArrayList;

public class Question3 {

	public static void main(String[] args) {
		Review r0 = new Review(4, "Good! Thx");
		Review r1 = new Review(3, "OK site");
		Review r2 = new Review(5, "Great!");
		Review r3 = new Review(2, "Poor! Bad.");
		Review r4 = new Review(3, "");
		Review[] reviews = {r0, r1, r2, r3, r4};
		ReviewAnalysis ra = new ReviewAnalysis(reviews);
		System.out.println("Part A: average rating = " + ra.getAverageRating());
		
		ArrayList<String> comments = ra.collectComments();
		System.out.println("\nPart B: collect comments");
		for (String comment : comments) {
			System.out.println(comment);
		}

	}

}
