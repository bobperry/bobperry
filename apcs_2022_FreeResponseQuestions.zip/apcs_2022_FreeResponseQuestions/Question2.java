package apcs_2022_FreeResponseQuestions;

public class Question2 {

	/*
	The following table contains a sample code execution sequence and the corresponding results. 
	The code execution sequence appears in a class other than Book or Textbook.
	*/
	public static void main(String[] args) {
		System.out.println("UNCOMMENT WHEN READY TO TEST...");
	/* UNCOMMENT WHEN READY TO TEST... 
		System.out.println("Textbook bio2015 = new Textbook(\"Biology\", 49.75, 2);");
		Textbook bio2015 = new Textbook("Biology", 49.75, 2);
		System.out.println();
		System.out.println("Textbook bio2019 = new Textbook(\"Biology\", 39.75, 3);");
		Textbook bio2019 = new Textbook("Biology", 39.75, 3);
		System.out.println();
		System.out.println("bio2019.getEdition() returns:\t\t" + bio2019.getEdition());
		System.out.println();
		System.out.println("bio2019.getBookInfo() returns:\t\t" + bio2019.getBookInfo());
		System.out.println();
		System.out.println("bio2019.canSubstituteFor(bio2015):\t" + bio2019.canSubstituteFor(bio2015));
		System.out.println();
		System.out.println("bio2015.canSubstituteFor(bio2019):\t" + bio2015.canSubstituteFor(bio2019));
		System.out.println();
		System.out.println("Textbook math = new Textbook(\"Calculus\", 45.25, 1);");
		Textbook math = new Textbook("Calculus", 45.25, 1); 
		System.out.println();
		System.out.println("bio2015.canSubstituteFor(math):\t\t" + bio2015.canSubstituteFor(math));	
	UNCOMMENT WHEN READY TO TEST... */
	}
}