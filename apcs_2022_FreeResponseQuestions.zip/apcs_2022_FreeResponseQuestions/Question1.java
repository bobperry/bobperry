package apcs_2022_FreeResponseQuestions;

public class Question1 {

	public static void main(String[] args) {
		System.out.println("Part A: ");
		Game g1 = new Game(true, 200, true, 100, true, 500, true);
		System.out.println(g1);
		Game g2 = new Game(true, 200, true, 100, false, 500, false);
		System.out.println(g2);
		Game g3 = new Game(true, 200, false, 100, true, 500, true);
		System.out.println(g3);
		Game g4 = new Game(false, 200, true, 100, true, 500, false);
		System.out.println(g4);
		
		GameB partB = new GameB();
		int maxScore = partB.playManyTimes(4);
		System.out.println("Part B: playManyTimes(4) called play() " + partB.rounds + " times and returned: " + maxScore);

	}

}
