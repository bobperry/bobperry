package apcs_2006_FreeResponseQuestions;

public class TimeInterval
{
    // returns true if interval overlaps with this TimeInterval
    // otherwise, returns false
    public boolean overlapsWith(TimeInterval interval) {
    	/* implementation not shown in PDF, provided by tutor */
    	return (interval.begin == this.begin) ||
    			(interval.begin > begin && interval.begin < this.end) || 
        		(interval.begin < begin && interval.end > this.begin);
    }
    
	// fields, constructors, and methods not shown in PDF
    private int begin;
    private int end;
    
    public TimeInterval(int begin, int end) {
        this.begin = begin;
        this.end = end;
    }

	@Override
	public String toString() {
		return " [" + begin + "," + end + ")";
	}
        
    
}
