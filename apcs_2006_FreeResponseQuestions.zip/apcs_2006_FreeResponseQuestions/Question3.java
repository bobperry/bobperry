package apcs_2006_FreeResponseQuestions;

import java.util.Arrays;

public class Question3
{
    public static void main(String[] args)
    {
    	Customer c1 = new Customer("Smith", 1001);
    	System.out.println("Customer c1 = new Customer(\"Smith\", 1001);");
    	Customer c2 = new Customer("Anderson", 1002);
    	System.out.println("Customer c2 = new Customer(\"Anderson\", 1002);");
    	Customer c3 = new Customer("Smith", 1003);
    	System.out.println("Customer c3 = new Customer(\"Smith\", 1003);");
    	System.out.println();
    	System.out.println("c1.compareCustomer(c1) returns " + c1.compareCustomer(c1));
    	System.out.println("c1.compareCustomer(c2) returns " + c1.compareCustomer(c2));
    	System.out.println("c1.compareCustomer(c3) returns " + c1.compareCustomer(c3));
    	System.out.println();
    	
        Customer[] list1 =
            {new Customer("Arthur", 4920), new Customer("Burton", 3911),
                new Customer("Burton", 4944), new Customer("Franz", 1692),
                new Customer("Horton", 9221), new Customer("Jones", 5554),
                new Customer("Miller", 9360), new Customer("Nguyen", 4339)};
        Customer[] list2 = {new Customer("Aaron", 1729),
            new Customer("Baker", 2921), new Customer("Burton", 3911),
            new Customer("Dillard", 6552), new Customer("Jones", 554),
            new Customer("Miller", 9360), new Customer("Noble", 9360)};
        Customer[] result = {null, null, null, null, null, null};
        
        System.out.println("Before merge:");

        System.out.println("list1 = " + Arrays.toString(list1));
        System.out.println("list2 = " + Arrays.toString(list2));
        System.out.println("result = " + Arrays.toString(result));
        System.out.println();
        Customer.prefixMerge(list1, list2, result);
        System.out.println("After merge:");
        System.out.println("list1 = " + Arrays.toString(list1));
        System.out.println("list2 = " + Arrays.toString(list2));
        System.out.println("result = " + Arrays.toString(result));
        System.out.println();
        System.out.println("list1 and list2 should be unchanged, and result should match PDF:");
        System.out.println("result = [(Aaron, 1729), (Arthur, 4920), (Baker, 2921), (Burton, 3911), (Burton, 4944), (Dillard, 6552)]");
        
        
        
    }
}
