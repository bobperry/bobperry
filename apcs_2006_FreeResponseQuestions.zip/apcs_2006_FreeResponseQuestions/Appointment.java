package apcs_2006_FreeResponseQuestions;

public class Appointment
{   
	// returns the TimeInterval of this Appointment
    public TimeInterval getTime() {
    	// implementation not shown in PDF, provided by tutor
        return time;
    }

    // returns true if the time interval of this Appointment
    // overlaps with the time interval of other;
    // otherwise, returns false
    public boolean conflictsWith(Appointment other) {
    	/* to be implemented in part (a) */
        return false;
    }
    
	// fields, constructors, and methods not shown in PDF
    private TimeInterval time;
    
    public Appointment(TimeInterval interval) {
        time = interval;
    }

	@Override
	public String toString() {
		return "Appointment time=" + time;
	}
    
}
