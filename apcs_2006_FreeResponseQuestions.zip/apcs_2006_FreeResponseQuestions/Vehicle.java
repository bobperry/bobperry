package apcs_2006_FreeResponseQuestions;

/*
Create the Vehicle class, which extends the TaxableItem class. A vehicle has two parts to its list
price: a dealer cost and dealer markup. The list price of a vehicle is the sum or the dealer cost and the dealer
markup.

For example, 
If a vehicle has a dealer cost of $20,000.00, a dealer markup of$2,500.00, and a tax rate of 0.10, 
then the list price of the vehicle would be $22,500.00 
and the purchase price (including tax) would be $24,750.00. 

If the dealer markup were changed to $1,000.00, 
then the list price of the vehicle would be $21,000.00 
and the purchase price would be $23,100.00.

Your class should have a constructor that takes dealer cost, the dealer markup, and the tax rate as
parameters. Provide any private instance variables needed and implement all necessary methods. Also
provide a public method changetMarkup, which changes the dealer markup to the value of its parameter.
 */
public class Vehicle // what is needed here?
{
	/* to be implemented in part (b) */
}
