package apcs_2006_FreeResponseQuestions;

public class Question1
{
    public static void main(String[] args)
    {
        Appointment first = new Appointment(new TimeInterval(900, 1200));
        Appointment second = new Appointment(new TimeInterval(1100, 1500));
        Appointment third = new Appointment(new TimeInterval(1600, 1800));
        System.out.println("Appointments:");
        System.out.println(" first: " + first);
        System.out.println(" second: " + second);
        System.out.println(" third: " + third);
        System.out.println();
        System.out.println("first.conflictsWith(second)? Should be true: " + first.conflictsWith(second));
        System.out.println("first.conflictsWith(third)? Should be false: " + first.conflictsWith(third));
        System.out.println("second.conflictsWith(first)? Should be true: " + second.conflictsWith(first));
        System.out.println("second.conflictsWith(third)? Should be false: " + second.conflictsWith(third));
        System.out.println("third.conflictsWith(first)? Should be false: " + third.conflictsWith(first));
        System.out.println("third.conflictsWith(second)? Should be false: " + third.conflictsWith(second));
        System.out.println();

        DailySchedule ds = new DailySchedule();
        ds.addAppt(new Appointment(new TimeInterval(500, 600)), false);
        ds.addAppt(new Appointment(new TimeInterval(800, 1000)), false);
        ds.addAppt(new Appointment(new TimeInterval(1100, 1200)), false);
        ds.addAppt(new Appointment(new TimeInterval(1400, 1900)), false);
        System.out.println(ds);        
        System.out.println();
        System.out.print("Can we add a regular appointment for 900 - 1130? ");
        System.out.println(ds.addAppt(new Appointment(new TimeInterval(900, 1130)), false));
        System.out.println(ds);        
        System.out.println();
        System.out.println("Clear conflicts for a 900 - 1130 appointment");
        ds.clearConflicts(new Appointment(new TimeInterval(900, 1130)));
        System.out.println(ds);
        System.out.println();
        System.out.print("Now, can we add a regular appointment for 900 - 1130? ");
        System.out.println(ds.addAppt(new Appointment(new TimeInterval(900, 1130)), false));
        System.out.println(ds);        
        System.out.println();
        System.out.println("Reset to original schedule.");
        DailySchedule ds2 = new DailySchedule();
        ds2.addAppt(new Appointment(new TimeInterval(500, 600)), false);
        ds2.addAppt(new Appointment(new TimeInterval(800, 1000)), false);
        ds2.addAppt(new Appointment(new TimeInterval(1100, 1200)), false);
        ds2.addAppt(new Appointment(new TimeInterval(1400, 1900)), false);
        System.out.println(ds2);
        System.out.println();
        System.out.print("Can we add an emergency appointment for 900 - 1130? ");
        System.out.println(ds2.addAppt(new Appointment(new TimeInterval(900, 1130)), true));
        System.out.println(ds2);
        
    }
}
