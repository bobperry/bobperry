package apcs_2006_FreeResponseQuestions;

import java.util.ArrayList;

public class DailySchedule {
	// contains Appointment objects, no two Appointments overlap
	private ArrayList<Appointment> apptList;

	public DailySchedule() {
		apptList = new ArrayList<>();
	}

	// removes all appointments that overlap the given Appointment
	// postcondition: all appointments that have a time conflict with
	//                appt have been removed from this DailySchedule
	public void clearConflicts(Appointment appt) {
		/* to be implemented in part (b) */
	}

	// if emergency is true, clears any overlapping appointments and adds
	// appt to this DailySchedule; otherwise, if there are no conflicting
	// appointments, adds appt to this Dailyschedule;
	// returns true if the appointment was added;
	// otherwise, returns false
	public boolean addAppt(Appointment appt, boolean emergency) { 
		/* to be implemented in part (c) */
		return false;
	}

	//There may be fields, constructors, and methods that are not shown.

	@Override
	public String toString() {
		String s = "DailySchedule:";
		for(Appointment a : apptList) {
			s += "\n  " + a;
		}
		return s;
	}

}
