package apcs_2006_FreeResponseQuestions;

public class Customer
{

    // constructs a Customer with given name and ID number
    public Customer(String name, int idNum)
    { 
    	/* implementation not shown in PDF */ 
        this.customerName = name;
        this.customerIdNum = idNum;
    }
    
    // returns the customer's name
    public String getName ()
    { 
    	/* implementation not shown in PDF */ 
        return customerName;
    }

    // returns the customer's id
    public int getID()
    { 
    	/* implementation not shown in PDF */ 
    	return customerIdNum;
    }
    
    // returns 0 when this customer is equal to other;
    // a positive integer when this customer is greater than other;
    // a negative integer when this customer is less than other
    public int compareCustomer (Customer other)
    { 
    	/* to be implemented in part (a) */ 
    	// Don't make assumptions about private field/variable names,
    	// use the public methods instead.
    	return 0;
    }

    
	 // fills result with customers merged from the
	 // beginning of listl and list2;
	 // result contains no duplicates and is sorted in
	 // ascending order by customer
	 // preconditions: 
	 //   result.length > 0;
	 //   listl.length >= result.length;
	 //   listl contains no duplicates;
	 //   list2.length >= result.length;
	 //   list2 contains no duplicates;
	 //   listl and list2 are sorted in
	 //   ascending order by customer
	 // postconditions: 
	 //   listl, list2 are not modified
    public static void prefixMerge(Customer[] list1, Customer[] list2, Customer[] result) {
    	/* to be implemented in part (b) */ 
    }
    
    // There may be fields, constructors, and methods that are not shown.
    private String customerName;
    private int customerIdNum;

    public String toString() {
        return "(" + customerName + ", " + customerIdNum + ")";
    }
}