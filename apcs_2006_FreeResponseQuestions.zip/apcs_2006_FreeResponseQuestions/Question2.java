package apcs_2006_FreeResponseQuestions;

import java.text.NumberFormat;

public class Question2 {
	public static void main(String[] args) {
        System.out.println("Uncomment when ready to test...");
        /* Uncomment when ready to test...
		
		NumberFormat usd = NumberFormat.getCurrencyInstance();
		System.out.println("If a vehicle has a dealer cost of $20,000.00, a dealer markup of$2,500.00, and a tax rate of 0.10, \r\n"
				+ "then the list price of the vehicle would be $22,500.00 \r\n"
				+ "and the purchase price (including tax) would be $24,750.00.\n");
		System.out.println("Using your code...");
		Vehicle car = new Vehicle(20000, 2500, 0.10);
		System.out.println(" List Price: " + usd.format(car.getListPrice()));
		System.out.println(" Purchase Price: " + usd.format(car.purchasePrice()));
		System.out.println();
		System.out.println("If the dealer markup were changed to $1,000.00, \r\n"
				+ "then the list price of the vehicle would be $21,000.00 \r\n"
				+ "and the purchase price would be $23,100.00.\n");
		System.out.println("Using your code...");
		car.changeMarkup(1000);
		System.out.println(" List Price: " + usd.format(car.getListPrice()));
		System.out.println(" Purchase Price: " + usd.format(car.purchasePrice()));

         */
	}
}
