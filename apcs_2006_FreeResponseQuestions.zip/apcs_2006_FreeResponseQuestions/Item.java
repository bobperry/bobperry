package apcs_2006_FreeResponseQuestions;

public interface Item
{
    double purchasePrice();
}
