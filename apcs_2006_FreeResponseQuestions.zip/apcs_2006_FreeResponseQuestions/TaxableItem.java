package apcs_2006_FreeResponseQuestions;

public abstract class TaxableItem implements Item
{
    private double taxRate;

    public abstract double getListPrice();

    public TaxableItem(double rate)
    {
        taxRate = rate;
    }

    public double purchasePrice()
    {
    	/* to be implemented in part (a) */
        return 0;
    }
}
