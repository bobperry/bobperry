package apcs_2009_FreeResponseQuestions;

public class NumberTile
{
    public int left;
    public int right;
    public int top;
    public int bottom;
    
    public NumberTile(int left, int right, int top, int bottom) {
        this.left = left;
        this.right = right;
        this.bottom = bottom;
        this.top = top;
    }
    public void rotate() {
        int tempLeft = left;
        left = bottom;
        bottom = right;
        right = top;
        top = tempLeft;
    }
    
    public int getLeft() {
        return left;
    }
    
    public int getRight() {
        return right;
    }

}
