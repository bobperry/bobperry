package apcs_2009_FreeResponseQuestions;

public class Question3
{
    public static void main(String[] args)
    {
        int[] rateTable = {50, 60, 160, 60, 80, 100, 100, 120, 150, 150,
                150, 200, 40, 240, 220, 220, 200, 200, 180, 180, 140, 100, 80, 60};

        BatteryCharger charger = new BatteryCharger(rateTable);
        
        System.out.println("1 hour of charge time started at hour 12 has a cost of 40.");
        System.out.println("Your code says it has a cost of: " + charger.getChargingCost(12, 1));
                          

        System.out.println("\n2 hours of charge time started at hour 0 has a cost of 110.");
        System.out.println("Your code says it has a cost of: " + charger.getChargingCost(0, 2));
        
        System.out.println("\n7 hours of charge time started at hour 22 has a cost of 550.");
        System.out.println("Your code says it has a cost of: " + charger.getChargingCost(22, 7));
        
        System.out.println("\n30 hours of charge time started at hour 22 has a cost of 3710.");
        System.out.println("Your code says it has a cost of: " + charger.getChargingCost(22, 30));
                
        System.out.println("\n1 hour of charging is cheapest when started at hour 12.");
        System.out.println("Your code says 1 hour of charging is cheapest when start at hour: " + charger.getChargeStartTime(1));
        
        System.out.println("\n2 hours of charging is cheapest when started at hour 0 or 23.");
        System.out.println("Your code says 2 hours of charging is cheapest when start at hour: " + charger.getChargeStartTime(2));

        System.out.println("\n7 hours of charging is cheapest when started at hour 22.");
        System.out.println("Your code says 7 hours of charging is cheapest when start at hour: " + charger.getChargeStartTime(7));

        System.out.println("\n30 hours of charging is cheapest when started at hour 22.");
        System.out.println("Your code says 30 hours of charging is cheapest when start at hour: " + charger.getChargeStartTime(30));
    }
}
