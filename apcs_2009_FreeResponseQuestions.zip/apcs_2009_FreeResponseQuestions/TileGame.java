package apcs_2009_FreeResponseQuestions;

import java.util.ArrayList;

public class TileGame
{
    private ArrayList<NumberTile> board;

    public TileGame(ArrayList<NumberTile> board) {
		this.board = board;
	}

	public TileGame()
    {
        board = new ArrayList<NumberTile>();
    }

    public int getIndexForFit(NumberTile tile)
    {
        return -1;
    }

    public boolean insertTile(NumberTile tile)
    {
        return false;
    }

}
