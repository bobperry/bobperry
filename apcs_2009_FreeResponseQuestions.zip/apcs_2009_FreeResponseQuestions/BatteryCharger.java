package apcs_2009_FreeResponseQuestions;

public class BatteryCharger
{
    private int[] rateTable;

    public BatteryCharger(int[] rateTable) {
		super();
		this.rateTable = rateTable;
	}

    public int getChargingCost(int startHour, int chargeTime) {
        return 0; 
    }

    public int getChargeStartTime(int chargeTime) {
        return 0; 
    }
}
