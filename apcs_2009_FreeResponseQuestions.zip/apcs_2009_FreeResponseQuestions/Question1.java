package apcs_2009_FreeResponseQuestions;

import java.util.Arrays;

public class Question1
{
	
    public static int[] getCubeTosses(NumberCube cube, int numTosses)
    {
    	return null;
    }

    public static int getLongestRun(int[] values)
    {
        return -1;
    }

	
    public static void main(String[] args) {
        NumberCube cube = new NumberCube();
        System.out.println("Your randomly generated array is: " + String.valueOf(Arrays.toString(getCubeTosses(cube, 10))));
        
        int[] example = {1,3,3,4,5,6,6,6};
        System.out.println("\nGiven the array [1,3,3,4,5,6,6,6], the index of the start of the longest run should be 5");
        System.out.println("Your code said: " + getLongestRun(example));
    }
}
