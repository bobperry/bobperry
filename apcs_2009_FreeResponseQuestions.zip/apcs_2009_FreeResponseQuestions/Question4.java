package apcs_2009_FreeResponseQuestions;

import java.util.ArrayList;

public class Question4
{
    public static void main(String[] args) {
        ArrayList<NumberTile> tileList = new ArrayList<NumberTile>();
        tileList.add(new NumberTile(4,3,4,7));
        tileList.add(new NumberTile(3,4,6,3));
        tileList.add(new NumberTile(4,2,1,3));
        tileList.add(new NumberTile(2,2,3,5));
        tileList.add(new NumberTile(2,9,5,2));
        TileGame game = new TileGame(tileList);        
        
        System.out.println("Adding tile1 to the board should return either 3 or 4.");
        System.out.println("Your code returns: " + game.getIndexForFit(new NumberTile(2,2,4,9)));
        System.out.println("Attempting to add tile2 to the board should return -1, as it can't be put in.");
        System.out.println("Your code returns: " + game.getIndexForFit(new NumberTile(8,2,4,9)));
        
        System.out.println("Adding the tile 1,6,2,2 (left, right, top, bottom) should return true.");
        System.out.println("Your code returns: " + game.insertTile(new NumberTile(1,6,2,2)));
        System.out.println("Adding the tile 6,6,6,6 (left, right, top, bottom) should return false.");
        System.out.println("Your code returns: " + game.insertTile(new NumberTile(6,6,6,6)));
    }
}
