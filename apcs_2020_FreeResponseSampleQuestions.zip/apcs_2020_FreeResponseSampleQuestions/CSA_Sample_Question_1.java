package apcs_2020_FreeResponseSampleQuestions;

import java.util.ArrayList;

public class CSA_Sample_Question_1 {
	public static void main(String[] args) {
		ArrayList<Gizmo> purchases = new ArrayList<>();
		purchases.add(new Gizmo("ABC", true));
		purchases.add(new Gizmo("ABC", false));
		purchases.add(new Gizmo("XYZ", true));
		purchases.add(new Gizmo("lmnop", false));
		purchases.add(new Gizmo("ABC", true));
		purchases.add(new Gizmo("ABC", false));
		OnlinePurchaseManager manager = new OnlinePurchaseManager(purchases);
		System.out.println(manager.countElectronicsByMaker(new String("ABC")));
		System.out.println(manager.countElectronicsByMaker(new String("lmnop")));
		System.out.println(manager.countElectronicsByMaker(new String("XYZ")));
		System.out.println(manager.countElectronicsByMaker(new String("QRP")));
		System.out.println(manager.hasAdjacentEqualPair());
		purchases.add(new Gizmo("ABC", false));
		System.out.println(manager.hasAdjacentEqualPair());

	}
}
