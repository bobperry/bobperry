package apcs_2020_FreeResponseSampleQuestions;

public class WordScrambler {

	private String[] scrambledWords;

	public WordScrambler(String[] wordArr) {
		scrambledWords = mixedWords(wordArr);
	}

	private String[] mixedWords(String[] wordArr) {
		return wordArr;
	}
	public boolean checkValidLength(String word1, String word2) {
		/* to be implemented in part (b) */
		return false;
	}


	public String recombine(String word1, String word2) {
		/* to be implemented in part (a) */
		return "";
	}
}
