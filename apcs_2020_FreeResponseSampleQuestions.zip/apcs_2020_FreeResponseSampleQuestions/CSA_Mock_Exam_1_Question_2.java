package apcs_2020_FreeResponseSampleQuestions;

public class CSA_Mock_Exam_1_Question_2 {

	public static void main(String[] args) {
		System.out.println(Hailstone.propLong(10));
	}

}
