package apcs_2020_FreeResponseSampleQuestions;

public class CSA_Mock_Exam_2_Question_2 {

	public static void main(String[] args) {
		String[] words = {"apple", "pear"};
		WordScrambler wS = new WordScrambler( words);
		System.out.println(wS.recombine("pear", "apple"));
		System.out.println(wS.checkValidLength("pear", "apple"));
		System.out.println(wS.recombine("apple", "pear"));
		System.out.println(wS.checkValidLength("apple","pear"));
	}

}
