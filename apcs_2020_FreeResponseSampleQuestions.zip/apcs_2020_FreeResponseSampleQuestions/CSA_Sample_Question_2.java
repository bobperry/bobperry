package apcs_2020_FreeResponseSampleQuestions;

public class CSA_Sample_Question_2 {
	public static void main(String[] args) {
		System.out.println(CheckDigit.getNumberOfDigits(283415)); //The number 283415 has 6 digits.
		System.out.println(CheckDigit.getDigit(283415, 1)); //	The first digit of 283415 is 2.
		System.out.println(CheckDigit.getDigit(283415, 5)); //The fifth digit of 283415 is 1.
		System.out.println("============================");
		System.out.println(CheckDigit.getCheck(159)); // 2 - The check digit for 159 is 2.
		System.out.println(CheckDigit.isValid(1592)); // true - The number 1592 is a valid combination of a number (159) and its check digit (2).
		System.out.println(CheckDigit.isValid(1593)); // false - The number 1593 is not a valid combination of a number (159) and its check digit (3) because 2 is the�check digit for 159.
	}

}
