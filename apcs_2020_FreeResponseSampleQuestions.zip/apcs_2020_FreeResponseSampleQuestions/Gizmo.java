package apcs_2020_FreeResponseSampleQuestions;

public class Gizmo {
	private String maker;
	private boolean electronic;

	public Gizmo(String maker, boolean electronic) {
		this.maker = maker;
		this.electronic = electronic;
	}

	/** Returns the name of the manufacturer of this Gizmo. */
	public String getMaker() {
		return maker;
	}

	/**
	 * Returns true if this Gizmo is electronic, and false otherwise.
	 */
	public boolean isElectronic() {
		return electronic;
	}

	/**
	 * Returns true if this Gizmo is equivalent to the Gizmo object represented
	 * by the parameter, and false otherwise.
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		Gizmo gizmo = (Gizmo) o;
		return electronic == gizmo.electronic && maker.equals(gizmo.maker);
	}

}
