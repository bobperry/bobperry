package apcs_2020_FreeResponseSampleQuestions;

public class CSA_Mock_Exam_2_Question_1 {

	public static void main(String[] args) {
		Stats stats = new Stats();
		System.out.println(stats);
		int[] scores = {82, 91, 79, 86, 82, 79, 86, 82, 79, 86, 82, 79, 86, 82, 79,  82};
		stats.recordScores(scores);
		System.out.println(stats);

	}

}
