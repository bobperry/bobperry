package apcs_2020_FreeResponseSampleQuestions;

public class CSA_Mock_Exam_1_Question_1 {

	public static void main(String[] args) {
		ReviewCollector rc = new ReviewCollector();
		System.out.println(rc);
		System.out.println(rc.getNumGoodReviews("Product 1"));
		rc.addReview(new ProductReview("Product 1", "This is the BEST product!"));
		System.out.println(rc);
		System.out.println(rc.getNumGoodReviews("Product 1"));
		rc.addReview(new ProductReview("Product 1", "This is the Best product!"));
		System.out.println(rc);
		System.out.println(rc.getNumGoodReviews("Product 1"));
		rc.addReview(new ProductReview("Product 1", "This is the best product!"));
		System.out.println(rc);
		System.out.println(rc.getNumGoodReviews("Product 1"));
		rc.addReview(new ProductReview("Product 2", "This is the best product!"));
		System.out.println(rc);
		System.out.println(rc.getNumGoodReviews("Product 1"));
	}

}
