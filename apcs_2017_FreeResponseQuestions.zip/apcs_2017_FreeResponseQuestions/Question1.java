package apcs_2017_FreeResponseQuestions;  // https://apcentral.collegeboard.org/pdf/ap17-frq-computer-science-a.pdf

public class Question1 {
	
	public static void main(String[] args) {
		System.out.println(new Digits(15704));
		System.out.println(new Digits(0));
		System.out.println(new Digits(7));
		System.out.println(new Digits(1356));
		System.out.println(new Digits(1336));
		System.out.println(new Digits(1536));
		System.out.println(new Digits(65310));
	}

}
