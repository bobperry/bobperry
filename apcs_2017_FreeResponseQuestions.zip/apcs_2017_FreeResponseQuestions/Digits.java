package apcs_2017_FreeResponseQuestions;

import java.util.ArrayList;

public class Digits {

	/**
	 * The list of digits from the number used to construct this object. The digits
	 * appear in the list in the same order in which they appear in the original
	 * number.
	 */

	private ArrayList<Integer> digitList;
	private int n;

	/**
	 * Constructs a Digits object that represents num. Precondition: num > = 0
	 */
	public Digits(int num) {
		n = num;
		/* to be implemented in part (a) */
	}

	/**
	 * Returns true if the digits in this Digits object are in strictly increasing
	 * order; false otherwise.
	 */
	public boolean isStrictlyIncreasing() {
		/* to be implemented in part (b) */
		return false;
	}
	
	public String toString() {
		return n + " ==> " + String.valueOf(digitList) + " ==> Is strictly increasing? " + this.isStrictlyIncreasing();
	}
}