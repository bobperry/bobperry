package apcs_2017_FreeResponseQuestions;

public class Phrase {

	private String currentPhrase;

	/** Constructs a new Phrase object. */
	public Phrase(String p) {
		currentPhrase = p;
	}

	/**
	 * Returns the index of the nth occurrence of str in the current phrase:
	 * returns -1 if the nth occurrence does not exist. 
	 * Precondition: str.length() > 0 and n > 0 
	 * Postcondition: the current phrase is not modified.
	 */
	public int findNthOccurrence(String str, int n) {
		int index = -1;
		for (int i = 0; i < n; i++) {
			index++;
			index = currentPhrase.indexOf(str, index);
			if (index == -1) break;
		}
		return index;
	}
	/**
	 * Modifies the current phrase by replacing the nth occurrence or str with repl.
	 * If the nth occurrence does not exist. th:e current phrase is unchanged.
	 * Precondition: str.length() > 0 and n > 0
	 */
	public void replaceNthOccurrence(String str, int n, String repl) {
		/* to be implemented in part (a) */ }

	/**
	 * Returns the index or the last occurrence of str in the current phrase:
	 * returns -1 if str is not round. 
	 * Precondition: str.length() > 0
	 * Postcondition: the current phrase is not modified.
	 */
	public int findLastOccurrence(String str) {
		/* to be implemented in part (b) */ 
		return 0;
	}

	/** Returns a string containing the current p.hrase. */
	public String toString() {
		return currentPhrase;
	}

}