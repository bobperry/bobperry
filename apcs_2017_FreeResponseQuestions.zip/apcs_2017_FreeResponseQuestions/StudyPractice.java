package apcs_2017_FreeResponseQuestions;

public interface StudyPractice {

	/** Returns the current practice problem. */
	String getProblem();
	
	/** Changes to the next practice problem. */
	void nextProblem();
	
}
