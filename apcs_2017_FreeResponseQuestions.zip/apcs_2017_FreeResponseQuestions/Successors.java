package apcs_2017_FreeResponseQuestions;

public class Successors {


	/** Returns the position of num in intArr;
	* returns null if no such element exists in intArr.
	* Precondition: intArr contains at least one row.
	*/
	public static Position findPosition(int num, int[][] intArr) {
		return null;
	}
	
	/** Returns a 20 successor array as described in part (b) constructed from i ntArr.
	* Precondition: int Arr contains at least o ne row and contains consecutive values.
	* Each of these integers may be in any position in the 2D array.
	*/
	public static Position[][] getSuccessorArray (int[][] intArr) {
		return null;
	}

}
