package apcs_2017_FreeResponseQuestions;

import java.util.Arrays;

public class Question4 {

	public static void main(String[] args) {
		int[][] arr = { { 15, 5, 9, 10 }, { 12, 16, 11, 6 }, { 14, 8, 13, 7 } };

		System.out.println("Input array:");
		for (int[] row : arr) {
			System.out.println("   " + Arrays.toString(row));
		}
		System.out.println();
		
		System.out.println("findPosition(8, arr) \n   returns " + Successors.findPosition(8, arr));
		System.out.println("findPosition(17, arr) \n   returns " + Successors.findPosition(17, arr));
		System.out.println();
		
		Position[][] posArray = Successors.getSuccessorArray(arr);
		System.out.println("Successors array:");
		if (posArray == null) 
			System.out.println("   null");
		else {
			for (Position[] row : posArray) {
				System.out.println("   " + Arrays.toString(row));
			}
		}
	}

}
