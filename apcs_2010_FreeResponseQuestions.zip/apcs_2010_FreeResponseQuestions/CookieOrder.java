package apcs_2010_FreeResponseQuestions;

public class CookieOrder {
	private String variety;
	private int numBoxes;

	/** Constructs a new CookieOrder object. */
	public CookieOrder(String variety, int numBoxes) {
		/* implementation not shown in PDF, provided by tutor Bob */
		super();
		this.variety = variety;
		this.numBoxes = numBoxes;
	}

	/**
	 * @return the variety of cookie being ordered
	 */
	public String getVariety() {
		/* implementation not shown in PDF, provided by tutor Bob */
		return variety;
	}


	/**
	 * @return the number of boxes being ordered
	 */
	public int getNumBoxes() {
		/* implementation not shown in PDF, provided by tutor Bob */
		return numBoxes;
	}

	// There may be instance variables, constructors, and methods that are not
	// shown.

	@Override
	public String toString() {
		return variety + ":" + numBoxes;
	}

}