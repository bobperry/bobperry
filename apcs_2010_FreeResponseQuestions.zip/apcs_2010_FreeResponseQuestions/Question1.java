package apcs_2010_FreeResponseQuestions;

public class Question1 {

	public static void main(String[] args) {
		MasterOrder goodies = new MasterOrder();
		goodies.addOrder(new CookieOrder("Chocolate Chip", 1));
		goodies.addOrder(new CookieOrder("Shortbread", 5));
		goodies.addOrder(new CookieOrder("Macaroon", 2));
		goodies.addOrder(new CookieOrder("Chocolate Chip", 3));
		System.out.println("goodies.getTotalBoxes() returns " + goodies.getTotalBoxes());
		System.out.println(goodies);
		System.out.println("goodies.removeVariety(\"Chocolate Chip\") returns " + goodies.removeVariety("Chocolate Chip"));
		System.out.println(goodies);
		System.out.println("goodies.removeVariety(\"Brownie\") returns " + goodies.removeVariety("Brownie"));
		System.out.println(goodies);
	}

}
