package apcs_2010_FreeResponseQuestions;

/*
Write the APLine class. Your implementation must include a constructor that has three integer parameters
that represent a, b, and c, in that order. You may assume that the values of the parameters representing a and b
are not zero. It must also include a method getSlope that calculates and returns the slope of the line, and a
method isOnLine that returns true if the point represented by its two parameters (x and y, in that
order) is on the APLine and returns false otherwise. Your class must produce the indicated results when
invoked by the code segment given above. You may ignore any issues related to integer overflow.
 */
public class APLine {
}