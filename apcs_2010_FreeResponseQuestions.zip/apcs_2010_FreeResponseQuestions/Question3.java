package apcs_2010_FreeResponseQuestions;

import java.util.Arrays;

public class Question3 {
	public static void main(String[] args) {
		int[] markers = { 100, 150, 105, 120, 90, 80, 50, 75, 75, 70, 80, 90, 100 };
		System.out.println("Trail Markers: " + Arrays.toString(markers));
		Trail trail = new Trail(markers);
		System.out.println("trail.isLevelTrailSegment(7, 10) = " + trail.isLevelTrailSegment(7, 10));
		System.out.println("trail.isLevelTrailSegment(2, 12) = " + trail.isLevelTrailSegment(2, 12));
		System.out.println("trail.isDifficult() = " + trail.isDifficult());
	}
}