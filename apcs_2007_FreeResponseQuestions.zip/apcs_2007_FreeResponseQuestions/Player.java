package apcs_2007_FreeResponseQuestions;

public class Player
{
    public String name;
    
    public Player(String aName) {
        name = aName;
    }
    
    public String getName() {
        return name;
    }
    
    public String getNextMove(GameState state) {
        return "";
    }
}
