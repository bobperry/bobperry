package apcs_2007_FreeResponseQuestions;

public class SelfDivisor
{
    public static boolean isSelfDivisor(int number)
    {
    	// To be implemented in part (a) 
        return false;
    }

    public static int[] firstNumSelfDivisors(int start, int num)
    {
    	// To be implemented in part (b) 
      return null;
    }
}
