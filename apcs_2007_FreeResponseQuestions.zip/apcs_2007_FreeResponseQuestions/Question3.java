package apcs_2007_FreeResponseQuestions;

import java.util.ArrayList;
import java.util.Arrays;

public class Question3 {
	public static void main(String[] args) {
		System.out.println("Part A:");
		ArrayList<StudentAnswerSheet> students = new ArrayList<>();
		StudentAnswerSheet example = new StudentAnswerSheet("Aaron", new ArrayList<>(Arrays.asList("A", "B", "D", "E", "A", "C", "?", "B", "D", "C")));
		ArrayList<String> ab = new ArrayList<>(Arrays.asList("A", "C", "D", "E", "B", "C", "E", "B", "B", "C"));
		System.out.println("Aaron should score a 5.25. \nYour code says Aaron scored: " + example.getScore(ab));
		students.add(new StudentAnswerSheet("Aaron", new ArrayList<>(Arrays.asList("A", "B", "D", "E", "A", "C", "?", "B", "D", "C"))));
		students.add(new StudentAnswerSheet("Bill", new ArrayList<>(Arrays.asList("A", "C", "D", "E", "A", "C", "D", "B", "B", "C"))));
		students.add(new StudentAnswerSheet("Clara", new ArrayList<>(Arrays.asList("B", "C", "D", "E", "A", "C", "E", "B", "B", "C"))));
		students.add(new StudentAnswerSheet("Debra", new ArrayList<>(Arrays.asList("A", "C", "D", "E", "B", "C", "E", "B", "?", "C"))));

		System.out.println("\nPart B:");
		TestResults exam = new TestResults(students);
		System.out.println("The highest scoring student should be Debra. \nYour code says the highest scoring student is: " + 
				exam.highestScoringStudent(new ArrayList<>(Arrays.asList("A", "C", "D", "E", "B", "C", "E", "B", "B", "C"))));
	}
}
