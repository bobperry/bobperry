package apcs_2007_FreeResponseQuestions;

import java.util.ArrayList;

public class StudentAnswerSheet
{
    private ArrayList<String> answers;
    public String studentName;

    public StudentAnswerSheet(String name, ArrayList<String> answer)
    {
        studentName = name;
        answers = answer;
    }

    public double getScore(ArrayList<String> key)
    {
    	// To be implemented in part (a) 
        return 0;
    }

    public String getName()
    {
        return studentName;
    }
}
