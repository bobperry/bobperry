package apcs_2007_FreeResponseQuestions;

/* Write the complete class declaration for a RandomPlayer class that is a subclass of Player.
 * The class should have a constructor whose String parameter is the player's name. 
 * It should override the getNextMove method to randomly select one of the valid moves in the 
 * given game state. If there are no valid moves available for the player, the string
 * "no move" should be returned. 
 */
public class RandomPlayer // what is needed here?
{
	// what is needed here?
}
