package apcs_2007_FreeResponseQuestions;

public class GameDriver {

	private GameState state; // the current state of the game

	public GameDriver(GameState initial) {
		state = initial;
	}

	/**
	 * Write the GameDriver method play. This method should first print the initial
	 * state of the game. It should then repeatedly determine the cmTent player and
	 * that player's next move, print both tl1e player's name and the chosen move,
	 * and make the move. When the game is over, it should stop making moves and
	 * print either the name of the winner and the word "wins" or the message "Game
	 * ends in a draw" if there is no winner. You may assume that the GameState
	 * makeMove method has been implemented so that it will properly handle any move
	 * description returned by the Player getNextMove method, including the string
	 * "no move". Complete method play below. 
	 * 
	 * Plays an entire game, as described in the problem description
	 */
	public void play() {
		/* to be implemented in part (b) */
	}

	// There may be fields, constructors, and methods that are not shown.
}