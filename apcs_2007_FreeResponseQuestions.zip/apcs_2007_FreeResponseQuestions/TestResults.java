package apcs_2007_FreeResponseQuestions;

import java.util.ArrayList;

public class TestResults
{
    public ArrayList<StudentAnswerSheet> sheets;

    public TestResults(ArrayList<StudentAnswerSheet> sheet)
    {
        sheets = sheet;
    }

    public String highestScoringStudent(ArrayList<String> key)
    {
    	// To be implemented in part (a) 
        return null;
    }

}
