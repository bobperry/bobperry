package apcs_2007_FreeResponseQuestions;

public class Question1
{
    public static void main(String[] args)
    {
        System.out.println("Part A: The following code should print: true, false, false");
        System.out.println("Your code prints: " + SelfDivisor.isSelfDivisor(128) + " " + SelfDivisor.isSelfDivisor(26) + " "
            + SelfDivisor.isSelfDivisor(550));

        System.out.println();
        int[] array = SelfDivisor.firstNumSelfDivisors(10, 3);
        if (array == null) {
        	System.out.println("Part B is not complete yet.");
        } else {
            System.out.println("Part B: The following code should print: 11, 12, 15");
            String ans = "";
            for(int a : array) ans += a + ", ";
            System.out.println("Your code prints: " + ans);
            
            System.out.println("The following code should print: 22, 24, 33, 36");
            int[] array2 = SelfDivisor.firstNumSelfDivisors(20, 4);
            String ans2 = "";
            for(int a : array2) ans2 += a + ", ";
            System.out.println("Your code prints: " + ans2);
        }
    }
}
