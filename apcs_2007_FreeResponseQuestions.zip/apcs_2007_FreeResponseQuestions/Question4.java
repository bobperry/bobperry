package apcs_2007_FreeResponseQuestions;

public class Question4
{
    public static void main(String[] args)
    {
        System.out.println("This would require writing code for an entire game in order to properly test.");
    }
}
