package apcs_2013_FreeResponseQuestions;

public class Question2 {

	public static void main(String[] args) {
		TokenPass t = new TokenPass(4);
		System.out.println("Initial state: " + t);
		for (int i = 0; i < 5; i++) {
			t.distributeCurrentPlayerTokens();
			t.incrementPlayer();
			System.out.println("After a turn, " + t);
		}
	}

}

