package apcs_2013_FreeResponseQuestions;

public class DownloadInfo {
	String title;
	int timesDownloaded;

	/**
	 * Creates a new instance with the given unique title and sets the number of
	 * times downloaded to 1.
	 *
	 * @param title the unique title of the downloaded song
	 */
	public DownloadInfo(String title) {
		/* implementation not shown in PDF, provided by Tutor Bob */
		this.title = title;
		timesDownloaded = 1;
	}

	/** @return the title */
	public String getTitle() {
		/* implementation not shown in PDF, provided by Tutor Bob */
		return title;
	}

	/** Increment the number times downloaded by 1 */
	public void incrementTimesDownloaded() {
		/* implementation not shown in PDF, provided by Tutor Bob */
		timesDownloaded++;
	}

// There may be instance variables, constructors, and methods that are not shown.

	@Override
	public String toString() {
		return "DownloadInfo [title=" + title + ", timesDownloaded=" + timesDownloaded + "]";
	}

}
