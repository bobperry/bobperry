package apcs_2013_FreeResponseQuestions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Question1 {

	public static void main(String[] args) {
		MusicDownloads webMusicA = new MusicDownloads();
		DownloadInfo hj = new DownloadInfo("Hey Jude");
		for (int i = 0; i < 4; i++) {
			hj.incrementTimesDownloaded();			
		}
		webMusicA.addDownload(hj);
		DownloadInfo ss = new DownloadInfo("Soul Sister");
		ss.incrementTimesDownloaded();
		ss.incrementTimesDownloaded();
		webMusicA.addDownload(ss);
		DownloadInfo al = new DownloadInfo("Aqualung");
		for (int i = 0; i < 9; i++) {
			al.incrementTimesDownloaded();			
		}
		webMusicA.addDownload(al);
		
		System.out.print("webMusicA.getDownloadInfo(\"Aqualung\") returns \n   ");
		System.out.println(webMusicA.getDownloadInfo("Aqualung"));
		System.out.println("***************************************************");
		System.out.print("webMusicA.getDownloadInfo(\"Happy Birthday\") returns \n   ");
		System.out.println(webMusicA.getDownloadInfo("Happy Birthday"));
		System.out.println("***************************************************");
		System.out.println(webMusicA);
		String[] songArray = {"Lights", "Aqualung", "Soul Sister", "Go Now", "Lights", "Soul Sister"} ;
		List<String> songList = new ArrayList<>(Arrays.asList(songArray));
		System.out.println("***************************************************");
		System.out.println("updateDownloads(" + songList + ")");
		System.out.println("***************************************************");
		webMusicA.updateDownloads(songList);
		System.out.println(webMusicA);
	}

}
