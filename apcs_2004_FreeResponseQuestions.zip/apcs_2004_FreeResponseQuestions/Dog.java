package apcs_2004_FreeResponseQuestions;

public class Dog extends Pet
{
    public Dog(String name) {
    	/* implementation not shown in PDF */
        super(name);
    }
    
    public String speak() {
    	/* implementation not shown in PDF */
        return "woof";
    }
}
