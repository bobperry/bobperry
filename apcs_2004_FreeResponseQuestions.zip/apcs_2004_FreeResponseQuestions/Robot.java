package apcs_2004_FreeResponseQuestions;

import java.util.Arrays;

public class Robot
{
    private int[] hall;
    private int pos;
    private boolean facingRight;

    /* Constructor not shown in PDF */
    public Robot(int[] toys, int position)
    {
        hall = toys;
        pos = position;
        facingRight = true;
    }

    /* postcondition: 
     * returns true if this Robot has a wall immediately in 
     * front of it, so that it cannot move forward;
     * otherwise, returns false;
     */
    public boolean forwardMoveBlocked()
    {
        /* to be implemented in part (a) */
    	return false;
    }

    /* postcondition: 
     * one move has been made according to the 
     * specifications above and the state of this 
     * Robot has been updated
     */
    public void move()
    {
        /* to be implemented in part (b) */
    	// If there are any items on the current tile, then one item is removed.        
        // If there are more items on the current tile, then the robot remains on 
        // the current tile facing in the same direction, but 
        // if there are no more items on the current tile...
        	// if the robot can move forward, it advances to the next tile in the direction
        	// that it is facing.
        	// otherwise, if the robot cannot move forward, it reverses direction and 
        	// does not change position.
    }

    /* postcondition: 
     * no more items remain in the hallway;
     * returns the number of moves made
     */
    public int clearHall()
    {
        /* to be implemented in part (c) */
        return 0;
    }

    /* postcondition: 
     * returns true if the hallway contains no items;
     * otherwise, returns false
     */
    public boolean hallIsClear()
    {
        /* implementation not shown in PDF, provided by tutor */
        for (int a : hall)
        {
            if (a != 0)
                return false;
        }
        return true;
    }
    
    public String toString() {
        /* implementation not shown in PDF, provided by tutor */
    	String s = "Hall: " + Arrays.toString(hall);
    	s += ", Robot at index " + pos;
    	s += ", facing right? " + facingRight;    	
        return s;
    }
}
