package apcs_2004_FreeResponseQuestions;

import java.util.ArrayList;

public class WordList
{
	private ArrayList<String> myList;
    
    public WordList(ArrayList<String> list) {
        myList = list;
    }
    
    public int numWordsOfLength(int len) {
    	/* to be implemented in part (a) */
        return 0;
    }
    
    public void removeWordsOfLength(int len) {
    	/* to be implemented in part (b) */
    }
    
    public String toString() {
        return String.valueOf(myList);
    }
}
