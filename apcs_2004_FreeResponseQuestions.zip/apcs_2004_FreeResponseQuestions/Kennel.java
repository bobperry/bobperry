package apcs_2004_FreeResponseQuestions;

import java.util.ArrayList;

public class Kennel
{
	private ArrayList<Pet> petList;
    
    public Kennel(ArrayList<Pet> pets) {
        petList = pets;
    }
    
    public void allSpeak() {
    	/* to be implemented in part c */
    }
}
