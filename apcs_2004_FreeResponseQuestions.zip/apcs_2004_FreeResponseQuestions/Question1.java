package apcs_2004_FreeResponseQuestions;

import java.util.ArrayList;
import java.util.Arrays;

public class Question1
{
    public static void main(String[] args)
    {
        ArrayList<String> list = new ArrayList<>(Arrays.asList("cat", "mouse", "frog", "dog", "dog"));
        WordList animals = new WordList(list);
        System.out.println("WordList animals: " + animals);
        System.out.println();
        System.out.println("animals.numWordsOfLength(4) should return 1, actually returns " + animals.numWordsOfLength(4));
        System.out.println("animals.numWordsOfLength(3) should return 3, actually returns " + animals.numWordsOfLength(3));
        System.out.println("animals.numWordsOfLength(2) should return 0, actually returns " + animals.numWordsOfLength(2));
        System.out.println();
        
        System.out.println("Calling animals.removeWordsOfLength(4)");        
        animals.removeWordsOfLength(4);
        System.out.println("WordList animals: " + animals);
        
        System.out.println();
        System.out.println("Calling animals.removeWordsOfLength(3)");        
        animals.removeWordsOfLength(3);
        System.out.println("WordList animals: " + animals);

        System.out.println();
        System.out.println("Calling animals.removeWordsOfLength(2)");        
        animals.removeWordsOfLength(2);
        System.out.println("WordList animals: " + animals);
    }
}
