package apcs_2004_FreeResponseQuestions;

import java.util.ArrayList;

public class Question2
{
    public static void main(String[] args)
    {
        ArrayList<Pet> pets = new ArrayList<>();
        pets.add(new Dog("Sparky"));

        System.out.println("Uncomment when ready to test...");
        /* Uncomment when ready to test...
        pets.add(new Cat("Ghost"));
        pets.add(new LoudDog("Woofer"));
        pets.add(new Cat("Whiskers"));
        pets.add(new LoudDog("Yapper"));
        
        Kennel ken = new Kennel(pets);
        System.out.println("This should return the following: \nSparky: woof\r\n" + 
            "Ghost: meow\r\n" + 
            "Woofer: woof woof\r\n" + 
            "Whiskers: meow\r\n" + 
            "Yapper: woof woof");
        System.out.println("\nIt actually returns:");
        ken.allSpeak();
        */
    }
}
