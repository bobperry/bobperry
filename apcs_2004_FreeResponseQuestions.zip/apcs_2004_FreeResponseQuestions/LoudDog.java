package apcs_2004_FreeResponseQuestions;

public class LoudDog // what is needed on this line?
{
	/* 
	 * Assume that class Dog has been declared as shown at the beginning of the question.
	 * If the String dog-sound is returned by the Dog method speak, then the LoudDog speak 
	 * returns a String containing dog-sound repeated two times.
	 * 
	 * Given the class hierarchy shown in the PDF, 
	 * write a complete class declaration for the class LoudDog,
	 * including implementations of its constructor and method(s).
	 */
}
