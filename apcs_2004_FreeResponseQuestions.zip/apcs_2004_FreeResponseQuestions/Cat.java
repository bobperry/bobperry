package apcs_2004_FreeResponseQuestions;

public class Cat // what is needed on this line?
{
	/* 
	 * Given the class hierarchy shown in the PDF, 
	 * write a complete class declaration for the class Cat,
	 * including implementations of its constructor and method(s).
	 * The Cat method speak returns "meow" when it is invoked.
	 */
}
