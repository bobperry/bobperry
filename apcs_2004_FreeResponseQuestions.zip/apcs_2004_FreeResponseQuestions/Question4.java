package apcs_2004_FreeResponseQuestions;

public class Question4
{
    public static void main(String[] args)
    {
        int[] hall = {1, 1, 2, 2};
        Robot robot = new Robot(hall, 1);
        System.out.print("Starting state: ");
        System.out.println(robot.toString());
        System.out.println("forwardMoveBlocked? " + robot.forwardMoveBlocked());
        System.out.println("hallIsClear? " + robot.hallIsClear());
        System.out.println();
        
        for(int i = 1; i <= 9; i++) {
        	robot.move();
            System.out.print("After move " + i + ": ");
            System.out.println(robot.toString());
            System.out.println("forwardMoveBlocked? " + robot.forwardMoveBlocked());
            System.out.println("hallIsClear? " + robot.hallIsClear());
            System.out.println();
        	
        }

        System.out.println("======================================");
        System.out.println("Resetting to original starting state.");
        System.out.println("======================================");
        System.out.println();
        hall = new int[] {1, 1, 2, 2};
        robot = new Robot(hall, 1);
        System.out.print("Starting state: ");
        System.out.println(robot.toString());
        System.out.println("forwardMoveBlocked? " + robot.forwardMoveBlocked());
        System.out.println("hallIsClear? " + robot.hallIsClear());
        System.out.println();

        System.out.println("Calling clearHall() ...");
        System.out.println("... took " + robot.clearHall() + " moves. (should be 9)");
        System.out.println();
        System.out.print("Ending state: ");
        System.out.println(robot.toString());
        System.out.println("forwardMoveBlocked? " + robot.forwardMoveBlocked());
        System.out.println("hallIsClear? " + robot.hallIsClear());
        
    }
}
