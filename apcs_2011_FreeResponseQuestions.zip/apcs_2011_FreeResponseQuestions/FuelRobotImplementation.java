package apcs_2011_FreeResponseQuestions;

public class FuelRobotImplementation implements FuelRobot {
	private int index = 0;
	private boolean facingRight = true;

	@Override
	public int getCurrentIndex() {
		return index;
	}

	@Override
	public boolean isFacingRight() {
		return facingRight;
	}

	@Override
	public void changeDirection() {
		facingRight = !facingRight;
	}

	@Override
	public void moveForward(int numLocs) {
		if(numLocs < 0) throw new IllegalArgumentException("numLocs must be non-negative, was: " + numLocs);
		if(facingRight) index += numLocs;
		else index -= numLocs;
	}

	@Override
	public String toString() {
		return "FuelRobot[index=" + index + ", facingRight=" + facingRight + "]";
	}

}
