package apcs_2011_FreeResponseQuestions;

import java.util.Arrays;

public class RouteCipher {
	/**
	 * A two-dimensional array of single-character strings, instantiated in the
	 * constructor
	 */
	private String[][] letterBlock;
	/** The number of rows of letterBlock, set by the constructor */
	private int numRows;
	/** The number of columns of letterBlock, set by the constructor */
	private int numCols;

	/**
	 * Places a string into letterBlock in row-major order.
	 *
	 * @param str
	 *            the string to be processed Postcondition: if str.length() <
	 *            numRows * numCols, "A" is placed in each unfilled cell if
	 *            str.length() > numRows * numCols, trailing characters are
	 *            ignored
	 */
	private void fillBlock(String str) {
		/* to be implemented in part (a) */
	}


	/**
	 * Extracts encrypted string from letterBlock in column-major order.
	 * Precondition: letterBlock has been filled
	 *
	 * @return the encrypted string from letterBlock
	 */
	private String encryptBlock() {
		/* implementation not shown in PDF, provided by Tutor Bob */
		String s = "";
		for (int col = 0; col < letterBlock[0].length; col++) {
			for (int row = 0; row < letterBlock.length; row++) {
				s += letterBlock[row][col];
			}
		}
		return s;
	}

	/**
	 * Encrypts a message.
	 *
	 * @param message
	 *            the string to be encrypted
	 * @return the encrypted message; if message is the empty string, returns
	 *         the empty string
	 */
	public String encryptMessage(String message) {
		/* to be implemented in part (b) */
		return "to be implemented in part (b)";
	}


	// There may be instance variables, constructors, and methods that are not
	// shown.

	public RouteCipher(int numRows, int numCols) {
		super();
		this.numRows = numRows;
		this.numCols = numCols;
		letterBlock = new String[numRows][numCols];
	}

	@Override
	public String toString() {
		String s = "Route Cipher letterBlock (" + numRows + "x" + numCols + "):";
		for (String[] row : letterBlock) {
			s += "\n\t" + Arrays.toString(row);
		}
		return s + "\n";
	}

}