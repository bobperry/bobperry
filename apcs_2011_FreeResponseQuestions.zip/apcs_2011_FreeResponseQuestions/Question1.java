package apcs_2011_FreeResponseQuestions;

import java.util.Arrays;

public class Question1 {

	public static void main(String[] args) {
/*
 (a) The volume of a sound depends on the amplitude of each value in the sound. The amplitude of a value is its
absolute value. For example, the amplitude of -2300 is 2300 and the amplitude of 4000 is 4000.

 Write the method limitAmplitude that will change any value that has an amplitude greater than the
given limit. Values that are greater than limit are replaced with limit, and values that are less than
-limit are replaced with �limit. The method returns the total number of values that were changed in
the array. For example, assume that the array samples has been initialized with the following values.
40 2532 17 -2300 -17 -4000 2000 1048 -420 33 15 -32 2030 3223
 When the statement
 int numChanges = limitAmplitude(2000);
 is executed, the value of numChanges will be 5, and the array samples will contain the following
values.
40 2000 17 -2000 -17 -2000 2000 1048 -420 33 15 -32 2000 2000
 */
		int[] valuesA = {40, 2532, 17, -2300, -17, -4000, 2000, 1048, -420, 33, 15, -32, 2030, 3223};
		Sound soundA = new Sound(valuesA);
		System.out.println("Before: " + Arrays.toString(soundA.getSamples()));
		System.out.println("limitAmplitude(2000)");
		int numChanges = soundA.limitAmplitude(2000);
		System.out.println("numChanges: " + numChanges);
		System.out.println("After: " + Arrays.toString(soundA.getSamples()));

/*
(b) Recorded sound often begins with silence. Silence in a sound is represented by a value of 0.
 Write the method trimSilenceFromBeginning that removes the silence from the beginning of a
sound. To remove starting silence, a new array of values is created that contains the same values as the
original samples array in the same order but without the leading zeros. The instance variable samples
is updated to refer to the new array. For example, suppose the instance variable samples refers to the
following array.
Index 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15
Value 0 0 0 0 -14 0 -35 -39 0 -7 16 32 37 29 0 0
 After trimSilenceFromBeginning has been called, the instance variable samples will refer to
the following array.
Index 0 1 2 3 4 5 6 7 8 9 10 11
Value -14 0 -35 -39 0 -7 16 32 37 29 0 0
 */
		int[] valuesB = {0, 0, 0, 0, -14, 0, -35, -39, 0, -7, 16, 32, 37, 29, 0, 0};
		Sound soundB = new Sound(valuesB);
		System.out.println("**************************************");
		System.out.println("Before: " + Arrays.toString(soundB.getSamples()));
		System.out.println("trimSilenceFromBeginning()");
		soundB.trimSilenceFromBeginning();
		System.out.println("After: " + Arrays.toString(soundB.getSamples()));

	}

}
