package apcs_2011_FreeResponseQuestions;

public interface FuelTank {
	/** @return an integer value that ranges from 0 (empty) to 100 (full) */
	int getFuelLevel();
}