package apcs_2011_FreeResponseQuestions;

public class FuelTankImplementation implements FuelTank {

	private int fuelLevel;

	public FuelTankImplementation(int fuelLevel) {
		super();
		this.fuelLevel = fuelLevel;
	}

	@Override
	public int getFuelLevel() {
		return fuelLevel;
	}

	public void setFuelLevel(int fuelLevel) {
		this.fuelLevel = fuelLevel;
	}

	@Override
	public String toString() {
		return "" + fuelLevel;
	}

}
