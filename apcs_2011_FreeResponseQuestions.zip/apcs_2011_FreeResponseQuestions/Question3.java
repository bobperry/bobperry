package apcs_2011_FreeResponseQuestions;

import java.util.ArrayList;
import java.util.List;

public class Question3 {

	public static void main(String[] args) {
		FuelRobotImplementation robot = new FuelRobotImplementation();
		robot.moveForward(2);
		List<FuelTank> tanks = new ArrayList<>();
		tanks.add(new FuelTankImplementation(20));
		tanks.add(new FuelTankImplementation(30));
		tanks.add(new FuelTankImplementation(80));
		tanks.add(new FuelTankImplementation(55));
		tanks.add(new FuelTankImplementation(50));
		tanks.add(new FuelTankImplementation(75));
		tanks.add(new FuelTankImplementation(20));
		FuelDepot fuelDepot = new FuelDepot(robot, tanks);
		System.out.println("**************************************");
		System.out.println(fuelDepot);
		System.out.println("**************************************");
		System.out.println("fuelDepot.nextTankToFill(50) returns " + fuelDepot.nextTankToFill(50));
		System.out.println("fuelDepot.nextTankToFill(15) returns " + fuelDepot.nextTankToFill(15));
		System.out.println("**************************************");
		System.out.println("Robot current state:\t" + robot);
		fuelDepot.moveToLocation(1);
		System.out.println("Move robot to index 1:\t" + robot);
	}

}
