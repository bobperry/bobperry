package apcs_2011_FreeResponseQuestions;

public class Question4 {

	public static void main(String[] args) {
		System.out.println("I can't test Part A separately, becuase the fillBlock method is private.");
		System.out.println("Please complete part B before testing.");
		System.out.println();
		
		RouteCipher cipher1 = new RouteCipher(2, 4);
		System.out.println("cipherA.encryptMessage(\"Surprise\") should return: Sruirspe");
		System.out.print("cipherA.encryptMessage(\"Surprise\")   does return: ");
		System.out.println(cipher1.encryptMessage("Surprise"));
		System.out.println(cipher1);

		RouteCipher cipher2 = new RouteCipher(3, 5);
		System.out.println("cipherA.encryptMessage(\"Meet at noon\") should return: Maoetne AtnA oA");
		System.out.print("cipherA.encryptMessage(\"Meet at noon\")   does return: ");
		System.out.println(cipher2.encryptMessage("Meet at noon"));
		System.out.println(cipher2);

		RouteCipher cipher3 = new RouteCipher(2, 3);
		System.out.println("cipherB.encryptMessage(\"Meet at midnight\") should return: Mte eati dmnitgAhA");
		System.out.print("cipherB.encryptMessage(\"Meet at midnight\")   does return: ");
		System.out.println(cipher3.encryptMessage("Meet at midnight"));
		System.out.println(cipher3);
	}

}