package apcs_2015_FreeResponseQuestions;

public class Question3 {

	public static void main(String[] args) {
		SparseArray sparse = new SparseArray(6,5);
		sparse.add(new SparseArrayEntry(1,4,4));		
		sparse.add(new SparseArrayEntry(2,0,1));
		sparse.add(new SparseArrayEntry(3,1,-9));
		sparse.add(new SparseArrayEntry(1,1,5));
		System.out.println(sparse);
		System.out.println();
		System.out.println("sparse.getValueAt(3, 1) returns " + sparse.getValueAt(3, 1));
		System.out.println("sparse.getValueAt(3, 3) returns " + sparse.getValueAt(3, 3));
		System.out.println();
		System.out.println("calling sparse.removeColumn(1)");
		sparse.removeColumn(1);
		System.out.println();
		System.out.println(sparse);
		
	}

}

/*
 
3. A two-dimensional array of integers in which most elements are zero is called a sparse array. Because most
elements have a value of zero, memory can be saved by storing only the non-zero values along with their row
and column indexes. The following complete SparseArrayEntry class is used to represent non-zero
elements in a sparse array. A SparseArrayEntry object cannot be modified after it has been constructed.

The SparseArray class represents a sparse array. It contains a list of SparseArrayEntry objects, each
of which represents one of the non-zero elements in the array. The entries representing the non-zero elements are
stored in the list in no particular order. Each non-zero element is represented by exactly one entry in the list.

The following table shows an example of a two-dimensional sparse array. Empty cells in the table indicate zero
values. 

  0 1 2 3 4
0
1   5     4
2 1
3   -9
4
5

The sample array can be represented by a SparseArray object, sparse, with the following instance
variable values. The items in entries are in no particular order; one possible ordering is shown below.

 numRows: 6
 numCols: 5
entries:
row: 1
col: 4
value: 4
row: 2
col: 0
value: 1
row: 3
col: 1
value: -9
row: 1
col: 1
value: 5

(a) Write the SparseArray method getValueAt. The method returns the value of the sparse array
element at a given row and column in the sparse array. If the list entries contains an entry with the
specified row and column, the value associated with the entry is returned. If there is no entry in entries
corresponding to the specified row and column, 0 is returned.
In the example above, the call sparse.getValueAt(3, 1) would return -9, and
sparse.getValueAt(3, 3) would return 0.


(b) Write the SparseArray method removeColumn. After removing a specified column from a sparse 
array:
� All entries in the list entries with column indexes matching col are removed from the list.
� All entries in the list entries with column indexes greater than col are replaced by entries
with column indexes that are decremented by one (moved one column to the left).
� The number of columns in the sparse array is adjusted to reflect the column removed.

The sample object sparse from the beginning of the question is repeated for your convenience.
  0 1 2 3 4
0
1   5     4
2 1
3  -9
4
5

The shaded entries in entries, below, correspond to the shaded column above.
 numRows: 6
numCols: 5
entries:
row: 1
col: 4
value: 4
row: 2
col: 0
value: 1
row: 3
col: 1
value: -9
row: 1
col: 1
value: 5

When sparse has the state shown above, the call sparse.removeColumn(1) could result in
sparse having the following values in its instance variables (since entries is in no particular order, it
would be equally valid to reverse the order of its two items). The shaded areas below show the changes.

numRows: 6
numCols: 4
entries:
row: 1
col: 3
value: 4
row: 2
col: 0
value: 1

Class information repeated from the beginning of the question
public class SparseArrayEntry
public SparseArrayEntry(int r, int c, int v)
public int getRow()
public int getCol()
public int getValue()

public class SparseArray
private int numRows
private int numCols
private List<SparseArrayEntry> entries
public int getNumRows()
public int getNumCols()
public int getValueAt(int row, int col)
public void removeColumn(int col) 

Complete method removeColumn. 

*/