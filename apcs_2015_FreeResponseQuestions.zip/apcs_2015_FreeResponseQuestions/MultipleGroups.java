package apcs_2015_FreeResponseQuestions;

import java.util.ArrayList;
import java.util.List;

public class MultipleGroups implements NumberGroup {
	private List<NumberGroup> groupList;

	public MultipleGroups() {
		super();
		groupList = new ArrayList<>();
	}
	
	public boolean add(NumberGroup ng) {
		return groupList.add(ng);
	}

	 /** Write the MultipleGroups method contains. 
	  * The method takes an integer and returns true if and only if the integer is contained
	  *  in one or more of the number groups in group List.
	  *   
	  * Returns true if at least one of the number groups in this multiple group contains num;
	  * 		false otherwise.
	  */
	public boolean contains(int num) {
		/* To be implemented in part c */
		return false;
	}

	@Override
	public String toString() {
		String s = "MultipleGroups:\n";
		for (NumberGroup numberGroup : groupList) {
			s += "   " + numberGroup + "\n";
		}
		return s;
	}

}
