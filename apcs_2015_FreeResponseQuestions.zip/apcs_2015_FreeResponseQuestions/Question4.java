package apcs_2015_FreeResponseQuestions;

public class Question4 {

	public static void main(String[] args) {
		System.out.println("UNCOMMENT WHEN READY TO TEST...");
	/* UNCOMMENT WHEN READY TO TEST... 
		NumberGroup ng = new Range(-3, 2);
		System.out.println(ng);
		System.out.println();
		NumberGroup ng1 = new Range(5, 8);
		System.out.println(ng1);
		NumberGroup ng2 = new Range(10, 12);
		System.out.println(ng2);
		NumberGroup ng3 = new Range(1, 6);
		System.out.println(ng3);
		MultipleGroups multiple1 = new MultipleGroups();
		multiple1.add(ng1);
		multiple1.add(ng2);
		multiple1.add(ng3);
		System.out.println(multiple1);
		System.out.println("multiple1.contains(2) returns " + multiple1.contains(2));
		System.out.println("multiple1.contains(9) returns " + multiple1.contains(9));
		System.out.println("multiple1.contains(6) returns " + multiple1.contains(6));
	UNCOMMENT WHEN READY TO TEST... */
	}

}


/*
4. This question involves the design of an interface, writing a class that implements the interface, and writing
a method that uses the interface.

(a) A number group represents a group of integers defined in some way. It could be empty, or it could contain
one or more integers.

Write an interface named NumberGroup that represents a group of integers. The interface should have
a single contains method that determines if a given integer is in the group. For example, if group1
is of type NumberGroup, and it contains only the two numbers -5 and 3, then
group1.contains(-5) would return true, and group1.contains(2) would return false.

Write the complete NumberGroup interface. It must have exactly one method.


(b) A range represents a number group that contains all (and only) the integers between a minimum value and
a maximum value, inclusive.

Write the Range class, which is a NumberGroup. The Range class represents the group of int
values that range from a given minimum value up through a given maximum value, inclusive. For example,
the declaration

 NumberGroup range1 = new Range(-3, 2);

represents the group of integer values -3, -2, -1, 0, 1, 2.

Write the complete Range class. Include all necessary instance variables and methods as well as a
constructor that takes two int parameters. The first parameter represents the minimum value, and the
second parameter represents the maximum value of the range. You may assume that the minimum is less
than or equal to the maximum.


(c) The MultipleGroups class (not shown) represents a collection of NumberGroup objects and is
a NumberGroup. The MultipleGroups class stores the number groups in the instance variable
groupList (shown below), which is initialized in the constructor.

 private List<NumberGroup> groupList;

Write the MultipleGroups method contains. The method takes an integer and returns true
if and only if the integer is contained in one or more of the number groups in groupList.
For example, suppose multiple1 has been declared as an instance of MultipleGroups and
consists of the three ranges created by the calls new Range(5, 8), new Range(10, 12),
and new Range(1, 6). The following table shows the results of several calls to contains.

Call 					Result
multiple1.contains(2) 	true
multiple1.contains(9) 	false
multiple1.contains(6) 	true

Complete method contains. 

*/