package apcs_2015_FreeResponseQuestions;
// Write the complete HiddenWord class, including any necessary instance variables, its constructor, and the method getHint. 
// You may assume that the length of the guess is the same as the length of the hidden word. 

