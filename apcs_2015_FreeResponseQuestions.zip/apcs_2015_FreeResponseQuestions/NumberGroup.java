package apcs_2015_FreeResponseQuestions;

// Write the complete NumberGroup interface. It must have exactly one method.
public interface NumberGroup {
	
}
