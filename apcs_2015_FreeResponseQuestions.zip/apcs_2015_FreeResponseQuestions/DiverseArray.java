package apcs_2015_FreeResponseQuestions;

public class DiverseArray {

	public static int arraySum(int[] arr1) {
		return 0;
	}

	public static int[] rowSums(int[][] mat1) {
		return null;
	}

	public static boolean isDiverse(int[][] mat1) {
		return false;
	}

}
