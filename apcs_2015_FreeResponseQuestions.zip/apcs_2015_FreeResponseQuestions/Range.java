package apcs_2015_FreeResponseQuestions;

// Write the complete Range class. 
// Include all necessary instance variables and methods 
// as well as a constructor that takes two int parameters. 
// The first parameter represents the minimum value, 
// and the second parameter represents the maximum value of the range. 
// You may assume that the minimum is less than or equal to the maximum.

public class Range // what is needed here?
{
	// I'm giving you these instance variables, because I need them in the toString() method I provide below...
	private int min;
	private int max;
	
	// what is needed here?
	
	
	// This toString() method is useful when running Question4.java's main method and printing Range instances
	public String toString() {
		return "Range [" + min + ", " + max + "]";
	}

}