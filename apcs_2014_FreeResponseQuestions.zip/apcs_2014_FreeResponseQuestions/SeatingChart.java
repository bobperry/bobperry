package apcs_2014_FreeResponseQuestions;

import java.util.List;

public class SeatingChart {
	
	private Student[][] seats;

	public SeatingChart(List<Student> studentList, int rows, int cols) {
	}
	
	public int removeAbsentStudents(int allowedAbsences) {
		return 0;
	}
	
	public String toString() {
		if (seats == null) return "seats is null";
		String s = "";
		for (Student[] row : seats) {
			for (Student student : row) {
				if(student == null)
					s += "null \t\t";
				else
					s += student + "\t";
			}
			s += "\n";
		}
		return s;
	}
	

}
