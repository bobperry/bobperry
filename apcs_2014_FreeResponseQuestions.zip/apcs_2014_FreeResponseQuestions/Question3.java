package apcs_2014_FreeResponseQuestions;

import java.util.ArrayList;
import java.util.List;

public class Question3 {

	public static void main(String[] args) {
		List<Student> roster = new ArrayList<>();
		roster.add(new Student("Karen", 3));
		roster.add(new Student("Liz", 1));
		roster.add(new Student("Paul", 4));
		roster.add(new Student("Lester", 1));
		roster.add(new Student("Henry", 5));
		roster.add(new Student("Renee", 9));
		roster.add(new Student("Glen", 2));
		roster.add(new Student("Fran", 6));
		roster.add(new Student("David", 1));
		roster.add(new Student("Danny", 3));
		SeatingChart sc = new SeatingChart(roster, 3,4);
		System.out.println(sc);
		System.out.printf("removed %d students whose absence count was > 4\n", sc.removeAbsentStudents(4));
		System.out.println(sc);


	}

}
