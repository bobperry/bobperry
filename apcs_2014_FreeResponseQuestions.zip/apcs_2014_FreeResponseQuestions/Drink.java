package apcs_2014_FreeResponseQuestions;

public class Drink extends SingleItem {

	public Drink(String name, double price) {
		super(name, price);
	}
}
