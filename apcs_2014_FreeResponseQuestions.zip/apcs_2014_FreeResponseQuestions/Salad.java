package apcs_2014_FreeResponseQuestions;

public class Salad extends SingleItem {

	public Salad(String name, double price) {
		super(name, price);
	}
}
