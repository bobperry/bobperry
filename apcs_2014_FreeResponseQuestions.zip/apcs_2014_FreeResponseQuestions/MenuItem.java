package apcs_2014_FreeResponseQuestions;

public interface MenuItem {
	String getName();
	double getPrice();
}
