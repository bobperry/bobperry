package apcs_2014_FreeResponseQuestions;

import java.text.NumberFormat;

public class Question4 {

	public static void main(String[] args) {
		Sandwich sandwich1 = new Sandwich("Cheeseburger", 2.75);
		Sandwich sandwich2 = new Sandwich("Club Sandwich", 2.75);
		Salad salad1 = new Salad("Spinach Salad", 1.25);
		Salad salad2 = new Salad("Coleslaw", 1.25);
		Drink drink1 = new Drink("Orange Soda", 1.25);
		Drink drink2 = new Drink("Cappuccino", 3.50);

		NumberFormat nf = NumberFormat.getCurrencyInstance();

		System.out.println("UNCOMMENT WHEN READY TO TEST...");
	/* UNCOMMENT WHEN READY TO TEST... 
		MenuItem trio1 = new Trio(sandwich1, salad1, drink1);
		MenuItem trio2 = new Trio(sandwich2, salad2, drink2);
		
		System.out.println(trio1.getName()+ ", price=" + nf.format(trio1.getPrice()));
		System.out.println(trio2.getName()+ ", price=" + nf.format(trio2.getPrice()));
	UNCOMMENT WHEN READY TO TEST... */

	}

}
