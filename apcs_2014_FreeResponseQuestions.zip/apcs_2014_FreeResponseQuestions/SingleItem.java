package apcs_2014_FreeResponseQuestions;

public class SingleItem implements MenuItem {
	private String name;
	private double price;
	

	public SingleItem(String name, double price) {
		super();
		this.name = name;
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}

}
