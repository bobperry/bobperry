package apcs_2014_FreeResponseQuestions;

public class Student {

	private String name;
	private int absenceCount;
	
	public Student(String name, int absenceCount) {
		super();
		this.name = name;
		this.absenceCount = absenceCount;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAbsenceCount() {
		return absenceCount;
	}

	public void setAbsenceCount(int absenceCount) {
		this.absenceCount = absenceCount;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return name + ",\t" + absenceCount ;
	}
	
	
}
