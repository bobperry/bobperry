package apcs_2014_FreeResponseQuestions;

import java.util.ArrayList;
import java.util.List;

public class Question1 {

	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		String word = "TAN";
		list.add(word);
		System.out.println(word + "\t\t" + scrambleWord(word));
		word = "ABRACADABRA";
		list.add(word);
		System.out.println(word + "\t" + scrambleWord(word));
		word = "WHOA";
		list.add(word);
		System.out.println(word + "\t\t" + scrambleWord(word));
		word = "AARDVARK";
		System.out.println(word + "\t" + scrambleWord(word));
		word = "APPLE";
		list.add(word);
		System.out.println(word + "\t\t" + scrambleWord(word));
		word = "EGGS";
		list.add(word);
		System.out.println(word + "\t\t" + scrambleWord(word));
		word = "A";
		System.out.println(word + "\t\t" + scrambleWord(word));
		word = "";
		System.out.println("\"" + word + "\"\t\t\"" + scrambleWord(word) + "\"");
		System.out.println("================================");
		System.out.println(list);
		scrambleOrRemove(list);
		System.out.println(list);
	}

	public static String scrambleWord(String word) {
		return null;
	}

	public static void scrambleOrRemove(List<String> wordList) {
	}
}
