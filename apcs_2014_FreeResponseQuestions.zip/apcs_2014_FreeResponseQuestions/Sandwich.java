package apcs_2014_FreeResponseQuestions;

public class Sandwich extends SingleItem {

	public Sandwich(String name, double price) {
		super(name, price);
	}
}
