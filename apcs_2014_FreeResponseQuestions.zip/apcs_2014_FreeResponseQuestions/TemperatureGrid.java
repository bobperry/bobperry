package apcs_2014_FreeResponseQuestions;

import java.util.Arrays;

public class TemperatureGrid
{
	private double[][ ] temps;

	public TemperatureGrid(double[][] temps) {
		super();
		this.temps = temps;
	}

	private double computeTemp(int row, int col)
	{
		return 0;
	}
	
	public boolean updateAllTemps(double tolerance)
	{
		return false;
	}

	public String toString() {
		String s = "";
		for (double[] row : temps) {
			s += Arrays.toString(row) + "\n";
		}
		return s;
	}
}
