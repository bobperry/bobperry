package apcs_2021_FreeResponseQuestions;

import java.util.Arrays;

public class Question4 {

	public static void main(String[] args) {
		int[][] arr = { { 2, 1, 0 }, { 1, 3, 2 }, { 0, 0, 0 }, { 4, 5, 6 } };

		System.out.println("int[][] arr = ");
		for (int[] row : arr) {
			System.out.println("  " + Arrays.toString(row));
		}

		System.out.println();
		System.out.println(
				"ArrayResizer.isNonZeroRow(arr, 0) should return false, returns: " + ArrayResizer.isNonZeroRow(arr, 0));
		System.out.println(
				"ArrayResizer.isNonZeroRow(arr, 1) should return true,  returns: " + ArrayResizer.isNonZeroRow(arr, 1));
		System.out.println(
				"ArrayResizer.isNonZeroRow(arr, 2) should return false, returns: " + ArrayResizer.isNonZeroRow(arr, 2));
		System.out.println(
				"ArrayResizer.isNonZeroRow(arr, 3) should return true,  returns: " + ArrayResizer.isNonZeroRow(arr, 3));

		System.out.println();
		System.out.println("int[][] smaller = ArrayResizer.resize(arr);");
		int[][] smaller = ArrayResizer.resize(arr);
		if (smaller == null) {
			System.out.println("smaller = null");
		} else {
			System.out.println("smaller = ");
			for (int[] row : smaller) {
				System.out.println("  " + Arrays.toString(row));
			}
		}

	}

}

/*
 * false At least one value in row 0 is zero. ArrayResizer.isNonZeroRow(arr, 1)
 * true All values in row 1 are non-zero. ArrayResizer.isNonZeroRow(arr, 2)
 * false At least one value in row 2 is zero. ArrayResizer.isNonZeroRow(arr, 3)
 * true All values in row 3 are non-zero.
 * 
 */
