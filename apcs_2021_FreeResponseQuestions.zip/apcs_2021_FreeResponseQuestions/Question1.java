package apcs_2021_FreeResponseQuestions;

public class Question1 {

	public static void main(String[] args) {
		/* a)
		Write the WordMatch method scoreGuess. To determine the score to be returned,
		scoreGuess finds the number of times that guess occurs as a substring of secret and then
		multiplies that number by the square of the length of guess. Occurrences of guess may overlap
		within secret.
		
		Assume that the length of guess is less than or equal to the length of secret and that guess is
		not an empty string.
		*/
		
		/*
		The following examples show declarations of a WordMatch object. The tables show the outcomes of
		some possible calls to the scoreGuess method.
		*/
		WordMatch game = new WordMatch("mississippi");
		
		System.out.println("Part (a)");
		System.out.println("First example:");
		System.out.println("WordMatch game = new WordMatch(\"mississippi\");");


		String guess = "i";
		int expected, result;
		String format = " Return Value of game.scoreGuess(\"%s\")     \tshould be %d, and your code returns %d\n";

		// Table in PDF shows:
		// Value of guess
		// Number of Substring Occurrences 
		// Score Calculation: (Number of Substring Occurrences) * (Square of the Length of guess)
		// Return Value of game.scoreGuess(guess)

		guess = "i";
		expected = 4;
		result = game.scoreGuess(guess);		
		System.out.printf(format, guess, expected, result);

		guess = "iss";
		expected = 18;
		result = game.scoreGuess(guess);		
		System.out.printf(format, guess, expected, result);

		guess = "issipp";
		expected = 36;
		result = game.scoreGuess(guess);		
		System.out.printf(format, guess, expected, result);

		guess = "mississippi";
		expected = 121;
		result = game.scoreGuess(guess);		
		System.out.printf(format, guess, expected, result);


		// second example... new game
		System.out.println("\nSecond example:");
		System.out.println("WordMatch game = new WordMatch(\"aaaabb\");");
		game = new WordMatch("aaaabb");

		guess = "a";
		expected = 4;
		result = game.scoreGuess(guess);		
		System.out.printf(format, guess, expected, result);

		guess = "aa";
		expected = 12;
		result = game.scoreGuess(guess);		
		System.out.printf(format, guess, expected, result);

		guess = "aaa";
		expected = 18;
		result = game.scoreGuess(guess);		
		System.out.printf(format, guess, expected, result);

		guess = "aabb";
		expected = 16;
		result = game.scoreGuess(guess);		
		System.out.printf(format, guess, expected, result);

		guess = "c";
		expected = 0;
		result = game.scoreGuess(guess);		
		System.out.printf(format, guess, expected, result);

		System.out.println("\nPart (b)");
		System.out.println("WordMatch game = new WordMatch(\"concatenation\");");
		game = new WordMatch ( "concatenation");
		
		guess = "ten";
		expected = 9;
		result = game.scoreGuess(guess);		
		System.out.printf(format, guess, expected, result);

		guess = "nation";
		expected = 36;
		result = game.scoreGuess(guess);		
		System.out.printf(format, guess, expected, result);

		System.out.println("  game.findBetterGuess(\"ten\", \"nation\") should return \"nation\" and actually returns \"" + game.findBetterGuess("ten", "nation") + "\"");
		
		guess = "con";
		expected = 9;
		result = game.scoreGuess(guess);		
		System.out.printf(format, guess, expected, result);

		guess = "cat";
		expected = 9;
		result = game.scoreGuess(guess);		
		System.out.printf(format, guess, expected, result);

		System.out.println("  game.findBetterGuess(\"con\", \"cat\") should return \"con\" and actually returns \"" + game.findBetterGuess("con", "cat") + "\"");

	}

}
