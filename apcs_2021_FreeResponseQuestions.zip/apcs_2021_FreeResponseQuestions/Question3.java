package apcs_2021_FreeResponseQuestions;

import java.util.ArrayList;

public class Question3 {

	public static void main(String[] args) {
		System.out.println("====================================");
		System.out.println("Part a)");
		ClubMembers clubMembers = new ClubMembers();
		System.out.println("Before adding members:");
		System.out.println(clubMembers);
		String[] names = { "George", "Abby", "Fred", "Sue", "Nina", "Bill", "Jane" };
		clubMembers.addMembers(names, 2023);
		System.out.println("After adding members:");
		System.out.println(clubMembers);

		System.out.println("====================================");
		System.out.println("Part b)");

		ArrayList<MemberInfo> memberList = new ArrayList<MemberInfo>();		
		memberList.add(new MemberInfo("SMITH, JANE", 2019, false));
		memberList.add(new MemberInfo("FOX, STEVE", 2018, true));
		memberList.add(new MemberInfo("XIN, MICHAEL", 2017, false));
		memberList.add(new MemberInfo("GARCIA, MARIA", 2020, true));
		clubMembers.setMemberList(memberList);

		System.out.println("The ArrayList memberList before the method call removeMembers(2018):");
		System.out.println(clubMembers);

		ArrayList<MemberInfo> gradsInGoodStanding = clubMembers.removeMembers(2018);
		
		System.out.println("The ArrayList memberList after the method call removeMembers(2018):");
		System.out.println(clubMembers);
		
		System.out.println("The ArrayList returned by the method call removeMembers(2018):");
		System.out.println("  Grads In Good Standing: " + gradsInGoodStanding);
		
	}

}
