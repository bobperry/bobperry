package apcs_2021_FreeResponseQuestions;

public class Question2 {

	public static void main(String[] args) {
		
		System.out.println("UNCOMMENT WHEN READY TO TEST...");
	/* UNCOMMENT WHEN READY TO TEST... 
		//	SingleTable tl has 4 seats, a view quality of 60.0, and a height of 74 centimeters.
		SingleTable t1 = new SingleTable(4, 60.0, 74);
		System.out.println("t1: " + t1);

		//	SingleTable t2 has 8 seats, a view quality of 70.0, and a height of 74 centimeters.
		SingleTable t2 = new SingleTable(8, 70.0, 74);
		System.out.println("t2: " + t2);

		// SingleTable t3 has 12 seats, a view quality of 75.0, and a height of 76 centimeters.
		SingleTable t3 = new SingleTable(12, 75.0, 76);
		System.out.println("t3: " + t3);
		
		System.out.println();
		CombinedTable c1 = new CombinedTable(t1, t2);
		System.out.println("CombinedTable c1 = new CombinedTable(t1, t2);");
		
		System.out.println(" c1.canSeat(9) should return true, actually returns " + c1.canSeat(9));

		System.out.println(" c1.canSeat(11) should return false, actually returns " + c1.canSeat(11));
		
		System.out.println(" c1.getDesirability() should return 65.0, actually returns " + c1.getDesirability());
		
		System.out.println();
		CombinedTable c2 = new CombinedTable(t2, t3);
		System.out.println("CombinedTable c2 = new CombinedTable(t2, t3);");
				
		System.out.println(" c2.canSeat(18) should return true, actually returns " + c2.canSeat(18));
		
		System.out.println(" c2.getDesirability() should return 62.5, actually returns " + c2.getDesirability());
		
		t2.setViewQuality(80);
		System.out.println(" t2.setViewQuality(80);");
		
		System.out.println(" c2.getDesirability() should return 67.5, actually returns " + c2.getDesirability());
	UNCOMMENT WHEN READY TO TEST... */
	}

}
