package apcs_2021_FreeResponseQuestions;

import java.util.ArrayList;

public class ClubMembers {

	// The PDF does not give any indication as to
	// whether or not memberList is initialized in the constructor of ClubMembers
	private ArrayList<MemberInfo> memberList;

	/**
	 * Adds new club members to memberList , as described in part (a). Precondition:
	 * names is a non-empty array.
	 */
	public void addMembers(String[] names, int gradYear) {
		/* to be implemented in part (a) */

		// The PDF does not give any indication as to
		// whether or not memberList is initialized in the constructor of ClubMembers,
		// but their solution for part (a) does not initialize it, so I initialize it in the constructor.

		// "All members added are initially in good standing
		// and share the same graduation year, gradYear"
	}

	/**
	 * Removes members who have graduated and returns a list of members who have
	 * graduated and are in good standing, as desc1ibed in part (b).
	 */
	public ArrayList<MemberInfo> removeMembers(int year) {
		/* to be implemented in part (b) */
		return null;
	}

	// There may be instance variables, constructors, and methods that are not
	// shown.

	public String toString() {
		return "  Member List: " + memberList + "\n";
	}

	public void setMemberList(ArrayList<MemberInfo> memberList) {
		this.memberList = memberList;
	}

	public ClubMembers() {
		super();
		memberList = new ArrayList<>();
	}

}
