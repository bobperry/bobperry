package apcs_2021_FreeResponseQuestions;

//The class SingleTable represents a table at a restaurant.
public class SingleTable {

	// There may be instance variables, constructors, and methods that are not shown.
	private int seats;
	private double viewQuality;
	private int height;

	public SingleTable(int seats, double viewQuality, int height) {
		super();
		this.seats = seats;
		this.viewQuality = viewQuality;
		this.height = height;
	}

	/**
	 * Returns the number of seats at this table. The value is always greater than
	 * or equal to 4.
	 */
	public int getNumSeats() {
		/* Implementation not shown in PDF */
		return seats;
	}

	/** Returns the height of this table in centimeters. */
	public int getHeight() {
		/* Implementation not shown in PDF */
		return height;
	}

	/** Returns the quality of the view from this table. */
	public double getViewQuality() {
		/* Implementation not shown in PDF */
		return viewQuality;
	}

	/** Sets the quality of the view from this table to value . */
	public void setViewQuality(double value) {
		/* Implementation not shown in PDF */
		viewQuality = value;
	}

	@Override
	public String toString() {
		return "SingleTable [seats=" + seats + ", viewQuality=" + viewQuality + ", height=" + height + "]";
	}

	
}
