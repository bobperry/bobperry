package apcs_2021_FreeResponseQuestions;

public class CombinedTable {
	/*
	 * Write the complete CombinedTable class. Your implementation must meet all
	 * specifications and conform to the examples shown in the chart in the PDF.
	 */
	
}
