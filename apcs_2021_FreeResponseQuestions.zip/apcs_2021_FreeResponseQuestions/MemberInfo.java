package apcs_2021_FreeResponseQuestions;

public class MemberInfo {
	// There may be instance variables, constructors, and methods that are not shown
	// in PDF.
	
	private String name;
	private int gradYear;
	private boolean hasGoodStanding;

	/**
	 * Constructs a MemberInfo object for the club member with name name, graduation
	 * year gradYear, and standing hasGoodStanding.
	 */
	public MemberInfo(String name, int gradYear, boolean hasGoodStanding) {
		/* Implementation not shown in PDF */
		this.name = name;
		this.gradYear = gradYear;
		this.hasGoodStanding = hasGoodStanding;		
	}

	/** Returns the graduation year of the club member. */
	public int getGradYear() {
		/* Implementation not shown in PDF */
		return gradYear;

	}

	/** Returns t rue if the member is in good standing and false otherwise. */
	public boolean inGoodStanding() {
		/* Implementation not shown in PDF */
		return hasGoodStanding;
	}

	@Override
	public String toString() {
		return "\n    MemberInfo [name=" + name + ", gradYear=" + gradYear + ", hasGoodStanding=" + hasGoodStanding + "]";
	}

	
}
