package apcs_2016_FreeResponseQuestions;

import java.util.Arrays;

public class Crossword {

	private Square[][] puzzle;

	public Crossword(boolean[][] blackSquares) {
		/* to be implemented in part (b) */
	}
	
	private boolean toBeLabeled(int r, int c, boolean[][] blackSquares){
		/* to be implemented in part (a) */
		return false;
	}

	@Override
	public String toString() {
		String s = "";
		for (Square[] squares : puzzle) {
			s+= Arrays.toString(squares) + "\n";
		}
		return s;
	}
	
}
