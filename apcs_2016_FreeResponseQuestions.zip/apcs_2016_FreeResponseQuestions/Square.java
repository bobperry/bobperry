package apcs_2016_FreeResponseQuestions;

public class Square {
	private boolean isBlack;
	private int num;

	public Square(boolean isBlack, int num) {
		this.isBlack = isBlack;
		this.num = num;
	}

	public boolean isBlack() {
		return isBlack;
	}

	public void setBlack(boolean isBlack) {
		this.isBlack = isBlack;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	@Override
	public String toString() {
//		return (isBlack? "█████" : "") + (num==0? "" : num) + "\t";
		return (isBlack? "XXXXX" : "") + (num==0? "" : num) + "\t";
	}
	
	
}
