package apcs_2016_FreeResponseQuestions;

import java.util.List;

public class Question2 {

	public static void main(String[] args) {
	       SystemLog log = new SystemLog();
	         log.addMessage("CLIENT3:security alert - repeated login failures");
	         log.addMessage("Webserver:disk offline");
	         log.addMessage("SERVER1:file not found");
	         log.addMessage("SERVER2:read error on disk DSK1");
	         log.addMessage("SERVER1:write error on disk DSK2");
	         log.addMessage("Webserver:error on /dev/disk");
	        
	       	List<LogMessage> messageList = log.getMessageList();
	       	for(LogMessage message : messageList) {
	       		System.out.println(message.getMachineId() + " :: " + message.getDescription());
	           }
	       	System.out.println("*****************");
	           List<LogMessage> contains = log.removeMessages("disk");
	       
	       	for(LogMessage message : contains) {
	       		System.out.println(message.getMachineId() + " :: " + message.getDescription());
	           }
	       
	       	System.out.println("*****************");
	       
	       	messageList = log.getMessageList();
	       	for(LogMessage message : messageList) {
	       		System.out.println(message.getMachineId() + " :: " + message.getDescription());
	           }

	}

}
