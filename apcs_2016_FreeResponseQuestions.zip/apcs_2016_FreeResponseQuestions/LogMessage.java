package apcs_2016_FreeResponseQuestions;

import java.util.ArrayList;
import java.util.List; 

public class LogMessage{
  private String machineId;
  private String description;
  
  public LogMessage(String message){
	  /* to be implemented in part (a) */
  }

  public boolean containsWord(String keyword){
	  /* to be implemented in part (b) */
	  return false;
  }
  public String getMachineId(){
    return machineId;
  }
  public String getDescription(){
    return description;
  }
}
