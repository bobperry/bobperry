package apcs_2016_FreeResponseQuestions;

import java.util.List;

public class StringFormatter {
	
	public static int totalLetters(List<String> wordList) {
		/* to be implemented in part (a) */
		return 0;
	}

	public static int basicGapWidth(List<String> wordList, int formattedLen) {
		/* to be implemented in part (b) */
		return 0;
	}

	public static int leftoverSpaces(List<String> wordList, int formattedLen) {
		int gaps = wordList.size() - 1;
		int spaces = formattedLen - totalLetters(wordList);
		return spaces % gaps;
	}

	public static String format(List<String> wordList, int formattedLen) {
		/* to be implemented in part (c) */
		return "to be implemented in part (c)";
	}

}
