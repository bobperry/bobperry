package apcs_2016_FreeResponseQuestions;

import java.util.ArrayList;
import java.util.List;

public class SystemLog {
	private List<LogMessage> messageList;

	public SystemLog() {
		messageList = new ArrayList<>();
	}

	public List<LogMessage> getMessageList() {
		return messageList;
	}

	public void addMessage(String message) {
		messageList.add(new LogMessage(message));
	}

	public List<LogMessage> removeMessages(String keyword) {
		/* to be implemented in part (c) */
		return null;
	}
}
