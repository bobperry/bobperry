package apcs_2016_FreeResponseQuestions;

import java.util.List;

public class Question3 {

	public static void main(String[] args) {
		boolean[][] blackSquares = { 
				{ true, false, false, true, true, true, false, false, false },
				{ false, false, false, false, true, false, false, false, false },
				{ false, false, false, false, false, false, true, true, true },
				{ false, false, true, false, false, false, true, false, false },
				{ true, true, true, false, false, false, false, false, false },
				{ false, false, false, false, true, false, false, false, false },
				{ false, false, false, true, true, true, false, false, true } };

		Crossword puzzle = new Crossword(blackSquares);
		System.out.println(puzzle);
	}
}
