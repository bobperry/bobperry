package apcs_2016_FreeResponseQuestions;

public class RandomLetterChooser extends RandomStringChooser {

	public RandomLetterChooser(String str) {
		/* to be implemented in part (b) */
	}

	public static String[] getSingleLetters(String str) {
		String[] letters = new String[str.length()];
		for (int i = 0; i < letters.length; i++) {
			letters[i] = str.substring(i, i+1);
		}
		return letters;
	}
}
