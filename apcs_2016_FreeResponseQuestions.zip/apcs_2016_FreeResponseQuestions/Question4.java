package apcs_2016_FreeResponseQuestions;

import java.util.ArrayList;
import java.util.List;

public class Question4 {

	public static void main(String[] args) {
		int formattedLen = 20;
		List<String> wordList1 = new ArrayList<>();
		wordList1.add("AP");
		wordList1.add("COMP");
		wordList1.add("SCI");
		wordList1.add("ROCKS");

		List<String> wordList2 = new ArrayList<>();
		wordList2.add("GREEN");
		wordList2.add("EGGS");
		wordList2.add("AND");
		wordList2.add("HAM");

		List<String> wordList3 = new ArrayList<>();
		wordList3.add("BEACH");
		wordList3.add("BALL");

		System.out.println("          1111111111<==");
		System.out.println("01234657890123465789<==");
		System.out.println("--------------------<==");
		System.out.println(StringFormatter.format(wordList1, formattedLen)+ "<==");
		System.out.println(StringFormatter.format(wordList2, formattedLen)+ "<==");
		System.out.println(StringFormatter.format(wordList3, formattedLen)+ "<==");
	}

}
