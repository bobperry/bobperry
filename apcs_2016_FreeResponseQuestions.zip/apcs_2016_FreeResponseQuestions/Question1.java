package apcs_2016_FreeResponseQuestions;
// https://apcentral.collegeboard.org/courses/ap-computer-science-a/exam
// https://secure-media.collegeboard.org/digitalServices/pdf/ap/ap16_frq_computer_science_a.pdf
// https://secure-media.collegeboard.org/digitalServices/pdf/ap/ap16_compsci_student_performance_qa.pdf
// https://apcentral.collegeboard.org/pdf/ap-computer-science-a-2014-java-quick-reference.pdf?course=ap-computer-science-a

public class Question1 {

	public static void main(String[] args) {
		System.out.println("UNCOMMENT WHEN READY TO TEST...");
	/* UNCOMMENT WHEN READY TO TEST... 
		String[] wordArray = {"wheels", "on", "the", "bus"};
		RandomStringChooser sChooser = new RandomStringChooser(wordArray);
		for (int i = 0; i < 6; i++) {
			System.out.print(sChooser.getNext() + " ");
		}
		System.out.println();
		RandomLetterChooser letterChooser = new RandomLetterChooser("cat");
		for (int i = 0; i < 4; i++) {
			System.out.print(letterChooser.getNext());
		}
	UNCOMMENT WHEN READY TO TEST... */
	}

}
